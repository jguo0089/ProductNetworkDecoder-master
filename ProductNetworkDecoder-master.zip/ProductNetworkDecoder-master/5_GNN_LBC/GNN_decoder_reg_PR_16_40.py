# # 在所有导入之前应用全局补丁
# import os
# import sys
#
# os.environ['DRJIT_LIBLLVM_PATH'] = 'C:/Program Files/LLVM15/bin/LLVM-C.dll'
# os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
#
# # 全局修补方案：在sys.modules中预先注册虚拟RT模块
# def setup_sionna_patch():
#     """在导入任何使用sionna的模块之前设置补丁"""
#     import types
#     import importlib
#
#     # 创建虚拟的RT相关模块
#     rt_modules = [
#         'sionna.rt',
#         'sionna.rt.scene',
#         'sionna.rt.antenna_array',
#         'sionna.rt.utils',
#         'sionna.rt.utils.electromagnetics',
#         'sionna.rt.utils.misc'
#     ]
#
#     for module_name in rt_modules:
#         if module_name not in sys.modules:
#             # 创建虚拟模块
#             dummy_module = types.ModuleType(module_name)
#             sys.modules[module_name] = dummy_module
#
#             # 为某些模块添加必要的虚拟属性
#             if module_name == 'sionna.rt.scene':
#                 dummy_module.load_scene = lambda *args, **kwargs: None
#                 dummy_module.Scene = type('Scene', (), {})
#             elif module_name == 'sionna.rt.antenna_array':
#                 dummy_module.AntennaArray = type('AntennaArray', (), {})
#             elif module_name == 'sionna.rt.utils':
#                 dummy_module.rotate = lambda *args, **kwargs: None
#             elif module_name == 'sionna.rt.utils.misc':
#                 # 创建虚拟的complex_sqrt函数
#                 def dummy_complex_sqrt(x):
#                     return x
#                 dummy_module.complex_sqrt = dummy_complex_sqrt
#
#     print("✓ Sionna RT模块补丁已应用")
#
# # 应用补丁
# setup_sionna_patch()
#
# import numpy as np
# import matplotlib.pyplot as plt
#
# try:
#     # 现在应该可以安全导入sionna和gnn模块了
#     from sionna.fec.utils import load_parity_check_examples, LinearEncoder, gm2pcm
#     from sionna.utils.plotting import PlotBER
#     from sionna.fec.ldpc import LDPCBPDecoder
#     print("✓ Sionna FEC components imported successfully")
# except Exception as e:
#     print(f"✗ Sionna import failed: {e}")
#
# try:
#     from gnn import * # load GNN functions
#     print("✓ GNN module imported successfully")
# except Exception as e:
#     print(f"✗ GNN import failed: {e}")
#     print("如果仍然失败，可能需要修改gnn.py文件")
#
# try:
#     from wbp import * # load weighted BP functions
#     print("✓ WBP module imported successfully")
# except Exception as e:
#     print(f"✗ WBP import failed: {e}")
#
# # 验证LLVM设置
# llvm_path = 'C:/Program Files/LLVM15/bin/LLVM-C.dll'
# print(f"LLVM-C.dll exists: {os.path.exists(llvm_path)}")
#
# print("补丁应用完成，可以继续运行其余代码")

# general imports
import tensorflow as tf
import numpy as np
#%matplotlib inline
import matplotlib.pyplot as plt

# load required Sionna components
from sionna.fec.utils import load_parity_check_examples, LinearEncoder, gm2pcm
from sionna.utils.plotting import PlotBER
from sionna.fec.ldpc import LDPCBPDecoder
#from sionna.fec.utils import generate_reg_ldpc_full_rank
from sionna.fec.utils import make_systematic
from TransferG_systematic_form import to_systematic_form, validate_ldpc_matrices

#%load_ext autoreload
#%autoreload 2
from gnn_BPSK_SNRcol  import * # load GNN functions
#from wbp import * # load weighted BP functions

tf.get_logger().setLevel('INFO') # ignore tf warnings related to autograph

gpus = tf.config.list_physical_devices('GPU')
print('Number of GPUs available :', len(gpus))
if gpus:
    gpu_num = 0 # Number of the GPU to be used
    try:
        #tf.config.set_visible_devices([], 'GPU')
        tf.config.set_visible_devices(gpus[gpu_num], 'GPU')
        print('Only GPU number', gpu_num, 'used.')
        tf.config.experimental.set_memory_growth(gpus[gpu_num], True)
    except RuntimeError as e:
        print(e)
        
#----- BCH -----
params={
    # --- Code Parameters ---
        "code": "reg-LDPC",
        "n_des": 144, # target codeword length (code generation may slightly increase n)
        "v": 4, # VN degree
        "c":7, # VN degree
        "k": 16,
        "n": 40,
    # --- GNN Architecture ----
        "num_embed_dims": 16,
        "num_msg_dims": 16,
        "num_hidden_units": 32,
        "num_mlp_layers": 2,
        "num_iter": 5,
        "reduce_op": "mean",
        "activation": "tanh",
        "clip_llr_to": None,
        "use_attributes": False,
        "node_attribute_dims": 0,
        "msg_attribute_dims": 0,
        # "return_infobits": False,
       "use_bias": False,
    # --- Training ---- # 
        "batch_size": [128, 128, 256], # bs, iter, lr must have same dim
        "train_iter": [50000, 200000, 300000],
        "learning_rate": [2e-4, 1e-4, 1e-5],
        "ebno_db_train": [0., 8.],
        "ebno_db_eval": 4,
        "batch_size_eval": 1000, # batch size only used for evaluation during training
        "eval_train_steps": 1000, # evaluate model every N iters
    # --- Log ----
        "save_weights_iter": 10000, # save weights every X iters
        "run_name": "PR_T5_16_40", # name of the stored weights/logs
        "save_dir": "results/PR_reg_T5_16_40/", # folder to store results
    # --- MC Simulation parameters ----
        "eval_dec_iter": 5, # number of decoding iters to evaluate
        "mc_iters": 10,
        "mc_batch_size": 100,
        "num_target_block_errors": 1000,
        "ebno_db_min": 0.,
        "ebno_db_max": 10.,
        "ebno_db_stepsize": 2,
        "eval_ns": [160],        
    # --- Weighted BP parameters ----
        "simulate_wbp": True, # simulate weighted BP as baseline
        "wbp_batch_size" : [1000, 1000, 1000],
        "wbp_train_iter" : [300, 2000, 2000],
        "wbp_learning_rate" : [1e-2, 1e-3, 1e-3],
        "wbp_ebno_train" : [2.5, 3., 3.5],
        "wbp_ebno_val" : 5., # validation SNR during training
        "wbp_batch_size_val" : 2000,
        "wbp_clip_value_grad" : 10, 
}




k=params["k"]
n=params["n"] 

# print('pcm:', pcm)
pcm=np.loadtxt('PR/H_pr_k16n40.txt')
encoder = LinearEncoder(pcm, is_pcm=True)






tf.random.set_seed(2) # we fix the seed to ensure stable convergence 

# init the GNN decoder
gnn_decoder = GNN_BP(pcm=pcm,
                     num_embed_dims=params["num_embed_dims"],
                     num_msg_dims=params["num_msg_dims"],
                     num_hidden_units=params["num_hidden_units"],
                     num_mlp_layers=params["num_mlp_layers"],
                     num_iter=params["num_iter"],
                     reduce_op=params["reduce_op"],
                     activation=params["activation"],
                     output_all_iter=True,
                     clip_llr_to=params["clip_llr_to"],
                     use_attributes=params["use_attributes"],
                     node_attribute_dims=params["node_attribute_dims"],
                     msg_attribute_dims=params["msg_attribute_dims"],
                     use_bias=params["use_bias"])
                     
e2e_gnn = E2EModel(encoder, gnn_decoder, k, n)

e2e_gnn(1, 1.)
e2e_gnn.summary()
#load_weights(e2e_gnn, "weights/LDPC_reg_T10_64_144_120000.npy")

train = True # remark: training takes several hours
if train:
    train_gnn(e2e_gnn, params)
else:
    # you can also load the precomputed weights
    load_weights(e2e_gnn, "weights/LDPC_reg_64_192new_370000.npy")


# ber_plot = PlotBER(f"GNN-based Decoding - {params['code']}, (k,n)=({k},{n})")
# ebno_dbs = np.arange(params["ebno_db_min"],
#                      params["ebno_db_max"]+1,
#                      params["ebno_db_stepsize"])


# for n_eval in params["eval_ns"]:
#     # generate new code for each length
#     # pcm, k, n, coderate = generate_reg_ldpc(v=params["v"], 
#     #                                         c=params["c"],  
#     #                                         n=n_eval, 
#     #                                         allow_flex_len=True, 
#     #                                         verbose=False)

#     encoder = LinearEncoder(pcm, is_pcm=True)
#     pcm=np.load('pcm_n192_4_6new.npy')
#     bp_decoder = LDPCBPDecoder(pcm,
#                                num_iter=params["eval_dec_iter"],
#                                hard_out=False)
#     e2e_bp = E2EModel(encoder, bp_decoder, k, n)
#     ber_plot.simulate(e2e_bp,
#                       ebno_dbs=ebno_dbs,
#                       batch_size=params["mc_batch_size"],
#                       num_target_block_errors=params["num_target_block_errors"],
#                       legend=f"BP-{bp_decoder._num_iter.numpy()} n={n}",
#                       soft_estimates=True,
#                       max_mc_iter=params["mc_iters"],
#                       forward_keyboard_interrupt=False,
#                       show_fig=False);


#     # simulate "conventional" BP performance first
#     # bp_decoder = LDPCBPDecoder(pcm,
#     #                            num_iter=params["eval_dec_iter"],
#     #                            hard_out=False)
#     # e2e_bp = E2EModel(encoder, bp_decoder, k, n)
#     # ber_plot.simulate(e2e_bp,
#     #                   ebno_dbs=ebno_dbs,
#     #                   batch_size=params["mc_batch_size"],
#     #                   num_target_block_errors=params["num_target_block_errors"],
#     #                   legend=f"BP-{bp_decoder._num_iter.numpy()} n={n}",
#     #                   soft_estimates=True,
#     #                   max_mc_iter=params["mc_iters"],
#     #                   forward_keyboard_interrupt=False,
#     #                   show_fig=False);

#     # instantiate new decoder for each number of iter (otherwise no retracing)
#     gnn_dec_temp = GNN_BP(pcm=pcm,
#                           num_embed_dims=params["num_embed_dims"],
#                           num_msg_dims=params["num_msg_dims"],
#                           num_hidden_units=params["num_hidden_units"],
#                           num_mlp_layers=params["num_mlp_layers"],
#                           num_iter=params["eval_dec_iter"],
#                           reduce_op=params["reduce_op"],
#                           activation=params["activation"],
#                           output_all_iter=False,
#                           clip_llr_to=params["clip_llr_to"],
#                           use_attributes=params["use_attributes"],
#                           node_attribute_dims=params["node_attribute_dims"],
#                           msg_attribute_dims=params["msg_attribute_dims"],
#                           use_bias=params["use_bias"])    
#     # generate new model   
#     model = E2EModel(encoder, gnn_dec_temp, k, n)
#     model(1,1.) # init model
#     # copy weights from trained decoder
#     model._decoder.set_weights(gnn_decoder.get_weights())

#     # and run the BER simulations
#     ber_plot.simulate(model,
#                      ebno_dbs=ebno_dbs,
#                      batch_size=params["mc_batch_size"],
#                      num_target_block_errors=params["num_target_block_errors"],
#                      legend=f"GNN-{params['eval_dec_iter']} n={n_eval}",
#                      soft_estimates=True,
#                      max_mc_iter=params["mc_iters"],
#                      forward_keyboard_interrupt=False,
#                      show_fig=True);