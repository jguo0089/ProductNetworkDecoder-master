# general imports
import tensorflow as tf
import numpy as np
#%matplotlib inline
import matplotlib.pyplot as plt

# load required Sionna components
from sionna.fec.utils import load_parity_check_examples, LinearEncoder, gm2pcm
from sionna.utils.plotting import PlotBER
from sionna.fec.ldpc import LDPCBPDecoder
#from sionna.fec.utils import generate_reg_ldpc_full_rank
from sionna.fec.utils import make_systematic
from TransferG_systematic_form import to_systematic_form, validate_ldpc_matrices

#%load_ext autoreload
#%autoreload 2
from gnn_BPSK_SNR import * # load GNN functions
#from wbp import * # load weighted BP functions

tf.get_logger().setLevel('INFO') # ignore tf warnings related to autograph

gpus = tf.config.list_physical_devices('GPU')
print('Number of GPUs available :', len(gpus))
if gpus:
    gpu_num = 0 # Number of the GPU to be used
    try:
        #tf.config.set_visible_devices([], 'GPU')
        tf.config.set_visible_devices(gpus[gpu_num], 'GPU')
        print('Only GPU number', gpu_num, 'used.')
        tf.config.experimental.set_memory_growth(gpus[gpu_num], True)
    except RuntimeError as e:
        print(e)
        
#----- BCH -----
params={
    # --- Code Parameters ---
        "code": "reg-LDPC",
        "n_des": 160, # target codeword length (code generation may slightly increase n)
        "v": 4, # VN degree
        "c":7, # VN degree
        "k": 16,
        "n": 40,
    # # --- GNN Architecture ----
    #     "num_embed_dims": 16,
    #     "num_msg_dims": 16,
    #     "num_hidden_units": 48,
    #     "num_mlp_layers": 3,
    #     "num_iter": 21,
    #     "reduce_op": "sum",
    #     "activation": "relu",
    #     "clip_llr_to": None,
    #     "use_attributes": False,
    #     "node_attribute_dims": 0,
    #     "msg_attribute_dims": 0,
    #     "return_infobits": False,
    #     "use_bias": True,   

     # --- GNN Architecture ----
        "num_embed_dims":20,
        "num_msg_dims":20,
        "num_hidden_units": 40,
        "num_mlp_layers": 2,
        "num_iter": 4,
        "reduce_op": "sum",
        "activation": "relu",
        "clip_llr_to":  None,
        "use_attributes": False,
        "node_attribute_dims": 0,
        "msg_attribute_dims": 0,
        #"return_infobits": False,
        "use_bias": False,     
    # --- Training ---- # 
        "batch_size": [128, 128, 256], # bs, iter, lr must have same dim
        "train_iter": [50000, 200000, 300000],
        "learning_rate": [2e-4, 1e-4, 1e-5],
        "ebno_db_train": [0., 8.],
        "ebno_db_eval": 4,          
        "batch_size_eval": 1000, # batch size only used for evaluation during training
        "eval_train_steps": 1000, # evaluate model every N iters
    # --- Log ----
        "save_weights_iter": 10000, # save weights every X iters
        "run_name": "LDPC_reg_i5_64_160relu630_V2", # name of the stored weights/logs
        "save_dir": "results/LDPC_reg_i5_64_160relu630/", # folder to store results
    # --- MC Simulation parameters ----
        "eval_dec_iter": 180, # number of decoding iters to evaluate
        "mc_iters": 10,
        "mc_batch_size": 1000,
        "num_target_block_errors": 10000,
        "ebno_db_min": 0.,
        "ebno_db_max": 8.,
        "ebno_db_stepsize":1,
        "eval_ns": [40],        
    # --- Weighted BP parameters ----
        "simulate_wbp": True, # simulate weighted BP as baseline
        "wbp_batch_size" : [1000, 1000, 1000],
        "wbp_train_iter" : [300, 2000, 2000],
        "wbp_learning_rate" : [1e-2, 1e-3, 1e-3],
        "wbp_ebno_train" : [2.5, 3., 3.5],
        "wbp_ebno_val" : 5., # validation SNR during training
        "wbp_batch_size_val" : 2000,
        "wbp_clip_value_grad" : 10, 
}


# def generate_reg_ldpc(v, c, n, allow_flex_len=True, verbose=True):
#     """Generate random regular (v,c) LDPC code.

#     This functions generates a random LDPC parity-check matrix of length ``n``
#     where each variable node (VN) has degree ``v`` and each check node (CN) has
#     degree ``c``. Please note that the LDPC code is not optimized to avoid
#     short cycles. For encoding, the :class:`~sionna.fec.utils.LinearEncoder`
#     layer can be used.

#     Input
#     -----
#     v : int
#         Desired variable node (VN) degree.

#     c : int
#         Desired check node (CN) degree.

#     n : int
#         Desired codeword length.

#     allow_flex_len: bool
#         Defaults to True. If True, the resulting codeword length can be
#         (slightly) increased.

#     verbose : bool
#         Defaults to True. If True, code parameters are printed.

#     Output
#     ------
#     (pcm, k, n, coderate):
#         Tuple:

#     pcm: ndarray
#         NumPy array of shape `[n-k, n]` containing the parity-check matrix.

#     k: int
#         Number of information bits per codeword.

#     n: int
#         Number of codewords bits.

#     coderate: float
#         Coderate of the code.


#     Note
#     ----
#     This algorithm only works for regular node degrees. For state-of-the-art
#     bit-error-rate performance, usually one needs to optimize irregular LDPC
#     codes.
#     """

#     # check input values for consistency
#     assert isinstance(allow_flex_len, bool), \
#                                     'allow_flex_len must be bool.'

#     # allow slight change in n to keep num edges
#     # from CN and VN perspective an integer
#     if allow_flex_len:
#         for n_mod in range(n, n+2*c):
#             if np.mod((v/c) * n_mod, 1.)==0:
#                 n = n_mod
#                 if verbose:
#                     print("Changing n to: ", n)
#                 break

#     # calculate number of nodes
#     coderate = 1 - (v/c) # to be checked
#     n_v = n
#     n_c = int((v/c) * n)
#     k = n_v - n_c

#     # generate sockets
#     v_socks = np.tile(np.arange(n_v),v)
#     c_socks = np.tile(np.arange(n_c),c)
#     if verbose:
#         print("Number of edges (VN perspective): ", len(v_socks))
#         print("Number of edges (CN perspective): ", len(c_socks))
#     assert len(v_socks) == len(c_socks), "Number of edges from VN and CN " \
#         "perspective does not match. Consider to (slightly) change n."

#     # apply random permutations
#     np.random.shuffle(v_socks)
#     np.random.shuffle(c_socks)

#     # and generate matrix
#     pcm = np.zeros([n_c, n_v])

#     idx = 0
#     shuffle_max = 1000 # stop if no success
#     shuffle_counter = 0
#     cont = True
#     while cont:
#         # if edge is available, take it
#         if pcm[c_socks[idx],v_socks[idx]]==0:
#             pcm[c_socks[idx],v_socks[idx]] = 1
#             idx += 1 # and go to next socket
#             shuffle_counter = 0 # reset counter
#             if idx==len(v_socks):
#                 cont=False
#         else: # shuffle sockets
#             shuffle_counter += 1
#             if shuffle_counter<shuffle_max:
#                 np.random.shuffle(v_socks[idx:])
#                 np.random.shuffle(c_socks[idx:])
#             else:
#                 print("Stopping - no solution found!")
#                 cont=False

#     v_deg = np.sum(pcm, axis=0)
#     c_deg = np.sum(pcm, axis=1)

#     #assert((v_deg==v).all()), "VN degree not always v."
#     #assert((c_deg==c).all()), "CN degree not always c."

#     if verbose:
#         print(f"Generated regular ({v},{c}) LDPC code of length n={n}")
#         print(f"Code rate is r={coderate}.")
#         plt.spy(pcm)

#     return pcm, k, n, coderate

# def peg_ldpc_constructor(k, n, max_n_increase=5, max_attempts=10):
#     """
#     Construct an LDPC code using the Progressive Edge Growth (PEG) algorithm.
    
#     Parameters:
#     k (int): Number of information bits
#     n (int): Desired codeword length
#     max_n_increase (int): Maximum allowed increase in n
#     max_attempts (int): Maximum number of attempts to construct the matrix
    
#     Returns:
#     numpy.ndarray: Parity-check matrix H
#     int: Actual codeword length used
#     """
#     def compute_local_girth(H, i, j):
#         """Compute the local girth for a potential new edge."""
#         m, n = H.shape
#         visited = set([(i, j)])
#         frontier = set([(i, j)])
#         girth = 0
        
#         while frontier:
#             new_frontier = set()
#             for v, u in frontier:
#                 if v < m:  # Check node
#                     new_nodes = [(v, col) for col in range(n) if H[v, col] == 1 and (v, col) not in visited]
#                 else:  # Variable node
#                     new_nodes = [(row, u) for row in range(m) if H[row, u] == 1 and (row, u) not in visited]
#                 new_frontier.update(new_nodes)
#                 visited.update(new_nodes)
            
#             frontier = new_frontier
#             girth += 1
            
#             if (i, j) in frontier:
#                 return 2 * girth
        
#         return float('inf')

#     for attempt in range(max_attempts):
#         for current_n in range(n, n + max_n_increase + 1):
#             m = current_n - k
#             H = np.zeros((m, current_n), dtype=int)
            
#             # Define variable node degrees (you can adjust this)
#             var_degrees = np.random.choice([2, 3, 4], size=current_n, p=[0.4, 0.3, 0.3])
            
#             for j in range(current_n):
#                 for _ in range(var_degrees[j]):
#                     if np.sum(H[:, j]) == 0:
#                         # For the first edge, choose the check node with the lowest degree
#                         i = np.argmin(np.sum(H, axis=1))
#                     else:
#                         # Find check nodes not connected to this variable node
#                         candidate_checks = [i for i in range(m) if H[i, j] == 0]
                        
#                         # Compute local girth for each candidate
#                         girths = [compute_local_girth(H, i, j) for i in candidate_checks]
                        
#                         # Choose the check node that maximizes local girth
#                         i = candidate_checks[np.argmax(girths)]
                    
#                     H[i, j] = 1
            
#             # Check if the matrix is valid (all rows and columns have at least one 1)
#             if np.all(np.sum(H, axis=1) > 0) and np.all(np.sum(H, axis=0) > 0):
#                 return H, k, current_n
    
#     raise ValueError(f"Failed to construct a valid LDPC code after {max_attempts} attempts")


# def make_full_rank(matrix):
#     """
#     Ensure the matrix is full rank by replacing linearly dependent rows
#     with random rows until full rank is achieved.
#     """
#     rows, cols = matrix.shape
#     rank = np.linalg.matrix_rank(matrix)
    
#     while rank < rows:
#         # Find linearly dependent rows
#         _, _, V = linalg.svd(matrix)
#         dependent_rows = np.where(np.abs(V[-1]) < 1e-10)[0]
        
#         # Replace one dependent row with a random row
#         random_row = np.random.randint(2, size=cols)
#         matrix[dependent_rows[0]] = random_row
        
#         # Recalculate rank
#         rank = np.linalg.matrix_rank(matrix)
    
#     return matrix

# def generate_full_rank_ldpc(v, c, n, allow_flex_len=True, verbose=True, max_attempts=1000):
#     """
#     Generate a full-rank LDPC parity-check matrix.
#     """
#     for _ in range(max_attempts):
#         pcm, k, n, coderate = generate_reg_ldpc(v, c, n, allow_flex_len, verbose)
#         if np.linalg.matrix_rank(pcm) == pcm.shape[0]:
#             return pcm, k, n, coderate
        
#         # If not full rank, try to fix it
#         pcm = make_full_rank(pcm)
#         if np.linalg.matrix_rank(pcm) == pcm.shape[0]:
#             return pcm, k, n, coderate
    
#     raise ValueError(f"Failed to generate a full-rank matrix after {max_attempts} attempts.")
# def systemize_generator_matrix(G):
#     k, n = G.shape
#     G = tf.cast(G, tf.float32)
    
#     # 高斯-约旦消元
#     for i in range(k):
#         # 找到第i列中第一个非零元素
#         pivot = i + tf.argmax(tf.abs(G[i:, i]) > 1e-10)
#         pivot = tf.minimum(pivot, k-1)  # 确保pivot不超过k-1
        
#         # 交换行
#         G = tf.tensor_scatter_nd_update(
#             G, 
#             [[i], [pivot]],
#             [tf.gather(G, pivot), tf.gather(G, i)]
#         )
        
#         # 将主元归一化
#         if tf.abs(G[i, i]) > 1e-10:
#             G = tf.tensor_scatter_nd_update(
#                 G,
#                 [[i]],
#                 [G[i] / G[i, i]]
#             )
        
#         # 消元
#         for j in range(k):
#             if j != i:
#                 factor = G[j, i]
#                 G = tf.tensor_scatter_nd_update(
#                     G,
#                     [[j]],
#                     [G[j] - factor * G[i]]
#                 )

#     # 确保前k列是单位矩阵
#     I_k = tf.eye(k, dtype=tf.float32)
#     P = G[:, k:]
#     G_sys = tf.concat([I_k, P], axis=1)
    
#     # 转换回二进制
#     G_sys = tf.math.mod(tf.round(G_sys), 2)
#     G_sys = tf.cast(G_sys, tf.int32)

#     return G_sys

# # pcm, k, n= peg_ldpc_constructor(k=params["k"], 
# #                                             n=params["n"],   
# #                                             max_n_increase=5, 
# #                                             max_attempts=10)
# ###最新的是根据这个得到的


# pcm, k, n, coderate = generate_reg_ldpc(v=params["v"], 
#                                         c=params["c"],  
#                                         n=params["n_des"], 
#                                         allow_flex_len=False, 
#                                         verbose=True)
# pcm, k, n, coderate = generate_full_rank_ldpc(v=params["v"], 
#                                               c=params["c"], 
#                                               n=params["n_des"], 
#                                               allow_flex_len=False)

k=params["k"]
n=params["n"] 

# print('pcm:', pcm)
# pcm=np.load('4_4_4/regularH_n160_k64_3_5_625.npy')
pcm=np.loadtxt('PR/H_pr_k16n40v2.txt')
encoder = LinearEncoder(pcm, is_pcm=True)

# 计算平均校验节点度数 (dc)
check_node_degrees = np.sum(pcm, axis=1)
dc = np.mean(check_node_degrees)

# 计算平均变量节点度数 (dv)
var_node_degrees = np.sum(pcm, axis=0)
dv = np.mean(var_node_degrees)

print(f"平均校验节点度数 (dc): {dc:.2f}")
print(f"平均变量节点度数 (dv): {dv:.2f}")


#np.save('pcm_n192_4_6new107.npy',pcm)
# np.savetxt('pcm_n192_4_6new.txt', pcm)

#print('c:', encoder.c)
# G=encoder.gm
# ##print('G:', encoder.gm)
# is_valid, message = validate_ldpc_matrices(pcm, G)
# print(f"Validation result: {is_valid}")
# # print(f"Message: {message}")
# # G = G.numpy()
# #G_systematic = to_systematic_form(G)
# G_sys = systemize_generator_matrix(G)
# np.save('G_n192_4_6new107.npy',G_sys )
# print("Generator matrix in systematic form:")
# print(G_systematic)
# params["k"] = k
# params["n"] = n





tf.random.set_seed(2) # we fix the seed to ensure stable convergence 

# init the GNN decoder
gnn_decoder = GNN_BP(pcm=pcm,
                     num_embed_dims=params["num_embed_dims"],
                     num_msg_dims=params["num_msg_dims"],
                     num_hidden_units=params["num_hidden_units"],
                     num_mlp_layers=params["num_mlp_layers"],
                     num_iter=params["num_iter"],
                     reduce_op=params["reduce_op"],
                     activation=params["activation"],
                     output_all_iter=True,
                     clip_llr_to=params["clip_llr_to"],
                     use_attributes=params["use_attributes"],
                     node_attribute_dims=params["node_attribute_dims"],
                     msg_attribute_dims=params["msg_attribute_dims"],
                     use_bias=params["use_bias"])
                     
e2e_gnn = E2EModel(encoder, gnn_decoder, k, n)

e2e_gnn(1, 1.)
e2e_gnn.summary()

train = False # remark: training takes several hours
if train:
    train_gnn(e2e_gnn, params)
else:
    # you can also load the precomputed weights
    load_weights(e2e_gnn, "weights/PR_T5_16_40vv1_550000.npy")


ber_plot = PlotBER(f"GNN-based Decoding - {params['code']}, (k,n)=({k},{n})")
ebno_dbs = np.arange(params["ebno_db_min"],
                     params["ebno_db_max"]+1,
                     params["ebno_db_stepsize"])


for n_eval in params["eval_ns"]:
    # generate new code for each length
    # pcm, k, n, coderate = generate_reg_ldpc(v=params["v"], 
    #                                         c=params["c"],  
    #                                         n=n_eval, 
    #                                         allow_flex_len=True, 
    #                                         verbose=False)
    pcm=np.loadtxt('PR/H_pr_k16n40v2.txt')
    encoder = LinearEncoder(pcm, is_pcm=True)

    # pcm=np.load('H_pcm_32_3_6_314.npy')
    # bp_decoder = LDPCBPDecoder(pcm,
    #                            num_iter=params["eval_dec_iter"],
    #                            hard_out=False)
    # e2e_bp = E2EModel(encoder, bp_decoder, k, n)
    # ber_plot.simulate(e2e_bp,
    #                   ebno_dbs=ebno_dbs,
    #                   batch_size=params["mc_batch_size"],
    #                   num_target_block_errors=params["num_target_block_errors"],
    #                   legend=f"BP-{bp_decoder._num_iter.numpy()} n={n}",
    #                   soft_estimates=True,
    #                   max_mc_iter=params["mc_iters"],
    #                   forward_keyboard_interrupt=False,
    #                   show_fig=False);


    # # simulate "conventional" BP performance first
    bp_decoder = LDPCBPDecoder(pcm,
                               num_iter=params["eval_dec_iter"],
                               hard_out=False)
    e2e_bp = E2EModel(encoder, bp_decoder, k, n)
    ber_plot.simulate(e2e_bp,
                      ebno_dbs=ebno_dbs,
                      batch_size=params["mc_batch_size"],
                      num_target_block_errors=params["num_target_block_errors"],
                      legend=f"BP-{bp_decoder._num_iter.numpy()} n={n}",
                      soft_estimates=True,
                      max_mc_iter=params["mc_iters"],
                      forward_keyboard_interrupt=False,
                      show_fig=False);

    # # instantiate new decoder for each number of iter (otherwise no retracing)
    # gnn_dec_temp = GNN_BP(pcm=pcm,
    #                       num_embed_dims=params["num_embed_dims"],
    #                       num_msg_dims=params["num_msg_dims"],
    #                       num_hidden_units=params["num_hidden_units"],
    #                       num_mlp_layers=params["num_mlp_layers"],
    #                       num_iter=params["eval_dec_iter"],
    #                       reduce_op=params["reduce_op"],
    #                       activation=params["activation"],
    #                       output_all_iter=False,
    #                       clip_llr_to=params["clip_llr_to"],
    #                       use_attributes=params["use_attributes"],
    #                       node_attribute_dims=params["node_attribute_dims"],
    #                       msg_attribute_dims=params["msg_attribute_dims"],
    #                       use_bias=params["use_bias"])    
    # # generate new model   
    # model = E2EModel(encoder, gnn_dec_temp, k, n)
    # model(1,1.) # init model
    # # copy weights from trained decoder
    # model._decoder.set_weights(gnn_decoder.get_weights())

    # # and run the BER simulations
    # ber_plot.simulate(model,
    #                  ebno_dbs=ebno_dbs,
    #                  batch_size=params["mc_batch_size"],
    #                  num_target_block_errors=params["num_target_block_errors"],
    #                  legend=f"GNN-{params['eval_dec_iter']} n={n_eval}",
    #                  soft_estimates=True,
    #                  max_mc_iter=params["mc_iters"],
    #                  forward_keyboard_interrupt=False,
    #                  show_fig=True);