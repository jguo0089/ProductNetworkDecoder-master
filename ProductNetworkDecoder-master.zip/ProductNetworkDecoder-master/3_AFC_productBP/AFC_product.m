%% AFC Product Code Main Program
clear; close all; clc;
% 
% % 添加这部分进行无噪声验证
% fprintf('=== Product AFC架构验证 ===\n');
% success_rate = verify_noiseless_reconstruction();
% if success_rate < 1.0
%     error('⚠️ 无噪声验证失败，请先修复架构问题再进行性能仿真！');
% end
% fprintf('=== 验证通过，开始性能仿真 ===\n\n');

% System parameters
k1=16;
k2=16;
k=k1*k2;
n1 = 18;                    % Row code length
n2 = 20;                   % Column code length
%rate = k / (n1 * n2);       % Code rate
w1 = [0.8949, 0.4462]; % Row code weights w2 = [0.1170 0.2340 0.4679 0.9373];
w2 = [0.8949, 0.4462]; % Column code weights

max_iter =3;              % Maximum number of decoding iterations
SNR_range = 0:2:12;        % SNR range in dB

ITER=10000;
ber = zeros(length(SNR_range),ITER);

for tot_idx = 1:ITER
     sprintf('Number of iterations = %u',tot_idx)
    % Simulate over SNR range
    %ber = zeros(size(SNR_range));
     block_error_count = 0; % Counter for block errors
    for snr_idx = 1:length(SNR_range)
        snr = SNR_range(snr_idx);
        %sigma = sqrt(1 / (2 * rate) * 10^(-snr/10));
    
        var = 1/10^(snr/10);
        sigma = sqrt(var);
        %sigma=0.00001;
    
        % Generate random message bits
        msg_org = randi([0, 1], 1, k);
    
        % BPSK modulation
        
        info_matrix = reshape(msg_org, k2, k1);
        msg_bits=1 - 2 *  info_matrix;
    
        % AFC Product Encoding
        [codeword_row, codeword_col, G1, G2] = AFCEncProduct(msg_bits, w1, w2, k1, k2, n1, n2);


        % 将两个码字合并成一个序列
        combined_codeword = [codeword_row, codeword_col];

       
        
        % AWGN channel - 整个序列一起过信道
        rx_combined = combined_codeword + normrnd(0, sigma, 1, length(combined_codeword));
        
        % 分离接收信号
        y_row = rx_combined(1:length(codeword_row));
        y_col = rx_combined(length(codeword_row)+1:end);


 
    
        % AFC Product Decoding
        [decoded_bits] = AFCDecProduct( y_row,  y_col, G1, G2, w1, w2, sigma, max_iter);
    
        % Compute bit error rate
    
        if any(msg_org ~= decoded_bits)
                block_error_count = block_error_count + 1;
        end
        ber(snr_idx,tot_idx) = sum(msg_org ~= decoded_bits) / k;
    end
    %BLER(snr_idx) = block_error_count / ITER;
end
BLER=sum(ber(:,:)>0,2)./ITER;
BER_avg = mean(ber, 2);  % 按行求平均，得到每个SNR的平均BER
