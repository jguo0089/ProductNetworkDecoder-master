% Message Passing decoder for the proposed modulation scheme
% G is the modulation matrix and its dimension is N*k
% k is the number of information symbols
% N is the number of received modulated signals
function [ soft_PY] = MPdecoder11_exp(b,u,G,W,sigma)

% W = 1./[2 3 5 7 11 13 17 19];
% W = W./sqrt(sum(W.^2));
flag_debug=0;
d = length(W);

ref = npermutek([-1 1],d-1);

%Generate table for first antenna: W1 = h1*W
temp_b = npermutek(0:1,d);
temp_b = 1-2*temp_b;

% hW = h*W;
table = temp_b*transpose(W);  %create 16 x 1 table with value of w

table0 = zeros(2^(d-1),d);
table1 = zeros(2^(d-1),d);
for m = 1:d
    %collect all the possible codeword values for bj = -1
    [table0(:,m),~,~] = find(temp_b(:,m) == 1);
    %collect all the possible codeword values for bj = 1
    [table1(:,m),~,~] = find(temp_b(:,m) == -1);
end

%% Initialization
T=15; % T is the maximum number of iterations
[N,k]=size(G);

PY = zeros(1,k);    %soft and hard decision initialization
soft_PY = PY;
PP = zeros(2,k);

% P=0.5*ones(1,k); % P(1,j) is the probaility that b_j=1

Q0=0.5*ones(N,k);   % Q is the message from from variable nodes to check nodes
Q1=Q0;
% for i = 1:k
%     [Vn,~,~] = find(G(:,i));
%     Q0(Vn,i) = 0.5;
%     Q1(Vn,i) = 0.5;
% end
R0=zeros(N,k);    %R is message from check to variable nodes
R1 = R0;
II=0.99;

pdf_noise = zeros(2^d,N);
for i = 1:N
    pdf_noise(:,i) = normpdf(u(1,i) - table(:,1),0,sigma);
    pdf_noise(:,i) = pdf_noise(:,i)/sum(pdf_noise(:,i));
end
Pu = pdf_noise;

for t=1:T
    
    % Check to variable node message update
    for i=1:N
        [~,Cn,Wn]=find(G(i,:));
        %d = length(Cn);
        %find what values of ci involve bj = -1;
        %index of the value of ci is stored in c_row-extracted from table_set
        %find the coefficient multiplying it for each value;
        %index of the weight is stored in c_col-extracted from G
        idx_w = zeros(1,d);
        idx_wn = idx_w;
        for m = 1:d
            %idx_w is the column in table_set that corresponds to bj
            idx_w(1,m) = find(W == Wn(1,m));
            idx_wn(1,m) = find(Wn == W(1,m));
        end
        
        m = 1;
        
        for j = Cn
            idx_wm = idx_wn;
            idx_wm(:,idx_w(1,m)) = [];
            c0_idx = table0(:,idx_w(1,m));
            c0_value = Pu(c0_idx,i);
            term0 = zeros(1,2^(d-1));
            
            c1_idx = table1(:,idx_w(1,m));
            c1_value = Pu(c1_idx,i);
            term1 = zeros(1,2^(d-1));
            
            
            for c_loop = 1:2^(d-1)
                prodQ = 1;
                
                for ii = 1:d-1
                    if(ref(c_loop,ii) == -1)
                        prodQ = prodQ*Q0(i,Cn(idx_wm(1,ii)));
                    end
                    if(ref(c_loop,ii) == 1)
                        prodQ = prodQ*Q1(i,Cn(idx_wm(1,ii)));
                    end
                end
                
                term0(1,c_loop) = c0_value(c_loop,1)*prodQ;
                term1(1,c_loop) = c1_value(c_loop,1)*prodQ;
            end
            R0(i,j)= sum(term0);
            R1(i,j)= sum(term1);
            %             LR(i,j) = R0(i,j)/R1(i,j);
            sQ=R0(i,j)+R1(i,j);
            R0(i,j)=R0(i,j)/sQ;
            R1(i,j)=R1(i,j)/sQ;
            m = m + 1;
        end
        
    end
    
    
    %% Variable to check node message update
    for j=1:k
        [Rn,~,~]=find(G(:,j));
        EE0=R0(Rn,j)';
        EE1=R1(Rn,j)';
        nn=1;
        for i=Rn'
            TT0=EE0;
            TT0(:,nn)=[];
            TT1=EE1;
            TT1(:,nn)=[];
            if isempty(TT0)==0
                Q0(i,j)= 0.5*prod(TT0);
                Q1(i,j)= 0.5*prod(TT1);
                sQ=Q0(i,j)+Q1(i,j);
                Q0(i,j)=Q0(i,j)/sQ;
                Q1(i,j)=Q1(i,j)/sQ;
            end
            nn=nn+1;
        end
    end
    %     t=t+1;
    %hard decision
    for j=1:k
        [Rn,~,~]=find(G(:,j));
        EE0=R0(Rn,j);
        EE1=R1(Rn,j);
        PP(1,j)= 0.5*prod(EE0);
        PP(2,j)= 0.5*prod(EE1);
        soft_PY(1,j) = log(PP(2,j)/PP(1,j));
        %        sQ=PP(1,j)+PP(2,j);
        %         PY(1,j)=PP(1,j)/sQ;
        if PP(1,j)> PP(2,j)
            PY(1,j)=0;
        else
            PY(1,j)=1;
        end
    end
    % if(flag_debug)
    %     II = nnz(b-PY)/k;
    % else
    %     II = nnz(b-PY)/k;
    % end

    if(II <= 1e-20)
        break
    end
end
% for j=1:k
%     [Rn,~,~]=find(G(:,j));
%     EE0=R0(Rn,j)';
%     EE1=R1(Rn,j)';
%     PP(1,j)= 0.5*prod(EE0);
%     PP(2,j)= 0.5*prod(EE1);
%     sQ=PP(1,j)+PP(2,j);
%     PY(1,j)=PP(1,j)/sQ;
%     if PY(1,j)>0.5
%         PY(1,j)=0;
%     else
%         PY(1,j)=1;
%     end
% end
end