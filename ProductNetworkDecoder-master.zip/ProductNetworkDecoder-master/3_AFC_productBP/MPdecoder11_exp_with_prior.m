function [soft_PY] = MPdecoder11_exp_with_prior(b, u, G, W, sigma, prior_llr)
% Message Passing decoder with prior LLR initialization
% b: original bits (can be empty [])
% u: received signal
% G: generator matrix (N x k)
% W: weight vector
% sigma: noise standard deviation  
% prior_llr: prior LLR values for initialization (can be empty [])

flag_debug = 0;
d = length(W);

ref = npermutek([-1 1], d-1);

% Generate table
temp_b = npermutek(0:1, d);
temp_b = 1 - 2 * temp_b;

table = temp_b * transpose(W);

table0 = zeros(2^(d-1), d);
table1 = zeros(2^(d-1), d);
for m = 1:d
    [table0(:,m), ~, ~] = find(temp_b(:,m) == 1);
    [table1(:,m), ~, ~] = find(temp_b(:,m) == -1);
end

%% Initialization
T = 10; % Maximum number of iterations
[N, k] = size(G);

PY = zeros(1, k);
soft_PY = PY;
PP = zeros(2, k);

% 修改的初始化部分
if ~isempty(prior_llr) && length(prior_llr) == k
    % 使用先验LLR初始化
    Q0 = zeros(N, k);
    Q1 = zeros(N, k);
    
    for j = 1:k
        llr_init = prior_llr(j);
        Q1_init = 1 / (1 + exp(-llr_init));%sigmoid函数转换映射
        Q0_init = 1 - Q1_init;
        
        [Rn, ~, ~] = find(G(:, j));
        for i = Rn'
            Q0(i, j) = Q0_init;
            Q1(i, j) = Q1_init;
        end
    end
    % 
    % Q0 = 0.5 * ones(N, k);
    % Q1 = Q0;
else
    % 原来的初始化方式
    Q0 = 0.5 * ones(N, k);
    Q1 = Q0;
end

R0 = zeros(N, k);
R1 = R0;
II = 0.99;

% PDF noise calculation
pdf_noise = zeros(2^d, N);
for i = 1:N
    pdf_noise(:, i) = normpdf(u(1, i) - table(:, 1), 0, sigma);
    pdf_noise(:, i) = pdf_noise(:, i) / sum(pdf_noise(:, i));
end
Pu = pdf_noise;

% Main iteration loop
for t = 1:T
    
    % Check to variable node message update
    for i = 1:N
        [~, Cn, Wn] = find(G(i, :));
        
        idx_w = zeros(1, d);
        idx_wn = idx_w;
        for m = 1:d
            idx_w(1, m) = find(W == Wn(1, m));
            idx_wn(1, m) = find(Wn == W(1, m));
        end
        
        m = 1;
        
        for j = Cn
            idx_wm = idx_wn;
            idx_wm(:, idx_w(1, m)) = [];
            c0_idx = table0(:, idx_w(1, m));
            c0_value = Pu(c0_idx, i);
            term0 = zeros(1, 2^(d-1));
            
            c1_idx = table1(:, idx_w(1, m));
            c1_value = Pu(c1_idx, i);
            term1 = zeros(1, 2^(d-1));
            
            for c_loop = 1:2^(d-1)
                prodQ = 1;
                
                for ii = 1:d-1
                    if ref(c_loop, ii) == -1
                        prodQ = prodQ * Q0(i, Cn(idx_wm(1, ii)));
                    end
                    if ref(c_loop, ii) == 1
                        prodQ = prodQ * Q1(i, Cn(idx_wm(1, ii)));
                    end
                end
                
                term0(1, c_loop) = c0_value(c_loop, 1) * prodQ;
                term1(1, c_loop) = c1_value(c_loop, 1) * prodQ;
            end
            
            R0(i, j) = sum(term0);
            R1(i, j) = sum(term1);
            sQ = R0(i, j) + R1(i, j);
            if sQ > 0
                R0(i, j) = R0(i, j) / sQ;
                R1(i, j) = R1(i, j) / sQ;
            end
            m = m + 1;
        end
    end
    
    % Variable to check node message update
    for j = 1:k
        [Rn, ~, ~] = find(G(:, j));
        EE0 = R0(Rn, j)';
        EE1 = R1(Rn, j)';
        nn = 1;
        for i = Rn'
            TT0 = EE0;
            TT0(:, nn) = [];
            TT1 = EE1;
            TT1(:, nn) = [];
            if ~isempty(TT0)
                Q0(i, j) = 0.5 * prod(TT0);
                Q1(i, j) = 0.5 * prod(TT1);
                sQ = Q0(i, j) + Q1(i, j);
                if sQ > 0
                    Q0(i, j) = Q0(i, j) / sQ;
                    Q1(i, j) = Q1(i, j) / sQ;
                end
            end
            nn = nn + 1;
        end
    end
    
    % Hard decision and LLR computation
    for j = 1:k
        [Rn, ~, ~] = find(G(:, j));
        EE0 = R0(Rn, j);
        EE1 = R1(Rn, j);
        PP(1, j) = 0.5 * prod(EE0);
        PP(2, j) = 0.5 * prod(EE1);
        
        % if PP(1, j) > 0 && PP(2, j) > 0
        %     soft_PY(1, j) = log(PP(2, j) / PP(1, j));
        % else
        %     soft_PY(1, j) = 0;
        % end
        
        soft_PY(1, j) = log(PP(2, j) / PP(1, j));
        if PP(1, j) > PP(2, j)
            PY(1, j) = 0;
        else
            PY(1, j) = 1;
        end
    end
    
    if II <= 1e-20
        break
    end
end

end