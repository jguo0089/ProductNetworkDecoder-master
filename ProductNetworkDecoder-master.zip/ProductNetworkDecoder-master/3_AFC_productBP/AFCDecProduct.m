function [decoded_bits] = AFCDecProduct(y_row, y_col, G1, G2, w1, w2, sigma, max_iter)
% AFC Product Decoding with iterative row-column decoding

% Get dimensions
[n1, k1] = size(G1);
[n2, k2] = size(G2);

% 修正reshape方式
y_row_matrix = reshape(y_row, k2, n1);  % k2行，每行长度n1
y_col_matrix = reshape(y_col, n2, k1);  % n2行，每行长度k1 (修正这里)

% 初始化LLR矩阵
llr_row = zeros(k2, k1);  % 行解码输出：k2行k1列
llr_col = zeros(k2, k1);  % 列解码输出：k2行k1列 (修正维度)

for iter = 1:max_iter
    
    %% 行解码 (Row Decoding)
    soft_row = zeros(k2, k1);

    if iter == 1
    % 第一次迭代，所有行都没有先验
    for j = 1:k2
        soft_row(j, :) = MPdecoder11_exp_with_prior([], y_row_matrix(j, :), G1, w1, sigma, []);
    end
   else
    % 后续迭代，所有行都使用列解码的先验
    for j = 1:k2
        prior_llr = llr_col(j, :);
        soft_row(j, :) = MPdecoder11_exp_with_prior([], y_row_matrix(j, :), G1, w1, sigma, prior_llr);
    end
    end
    llr_row = soft_row;
    
    %% 列解码 (Column Decoding)
    soft_col = zeros(k2, k1);
    for i = 1:k1
         % 使用行解码的输出作为先验
        prior_llr = llr_row(:, i)';  % 第i列的先验LLR
        col_output = MPdecoder11_exp_with_prior([], y_col_matrix(:, i)', G2, w2, sigma, prior_llr);
        
        soft_col(:, i) = col_output';  % 转置后存储
    end
    llr_col = soft_col;
    %llr_col = soft_row;
    
end

% 最终判决 - 重新整理成原始info的形状
info_matrix_decoded = (llr_col > 0);  % LLR < 0 表示bit = 0

decoded_bits = info_matrix_decoded(:)';  % 按列展开成向量
%decoded_bits = reshape(info_matrix_decoded, 1, []); % 按行展开成向量

end