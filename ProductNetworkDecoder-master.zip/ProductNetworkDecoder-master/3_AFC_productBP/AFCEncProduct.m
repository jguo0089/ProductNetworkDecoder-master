function [codeword_row, codeword_col, G1, G2] = AFCEncProduct(info, w1, w2, k1, k2, n1, n2)
% This encodes 'info' to generate the codeword 'codeword' and
% generator matrices 'G1' and 'G2' for AFC Product Code
% w1 and w2 are the weight vectors for row and column encoding
% n1 and n2 are the codeword lengths for row and column codes

% Get the dimensions of info
k = length(info);
% k1 = n1 / (length(w1) + 1);
% k2 = k / k1;
% k1 = 8;
% k2 = 8;
% Reshape info into matrix form
info_matrix = info;

% Row encoding
row_codewords = zeros(k2, n1);
for i = 1:k2
    [row_codewords(i, :), G1] = AFCEnc2(info_matrix(i, :), w1, n1);
end

% Column encoding
col_codewords = zeros(n2, k1);
for j = 1:k1
    [col_codewords(:, j), G2] = AFCEnc2(info_matrix(:, j), w2, n2);
end

% Reshape codeword into vector form
codeword_col = col_codewords(:)';
codeword_row = row_codewords(:)';
end