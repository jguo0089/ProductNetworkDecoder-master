function [ check, G ,dmin] = AFCEnc2(info,w,n)
%This encodes 'info' into generate the codeword 'output_symbol'
%and generator matrix 'G'
d = length(w);
k = length(info);
w = sort(w,'descend');
x = floor((w.^2)./(w(d))^2);

Gidx = zeros(n,k);
value = zeros(1,k);

for i = 1:n
    [~,order_idx] = sort(value,'ascend');
    Gidx(i,order_idx(1:d)) = 1:d;
    value(order_idx(1:d)) = value(order_idx(1:d)) + x;
end



G = Gidx;
for i = 1:d
    G(G == i) = w(i);
end
size(G);
size(info);


[m, n] = size(info);
if m==1
    check = (G*info')';
else
    check = (G*info)';


end