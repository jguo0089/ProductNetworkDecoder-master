% 示例使用
x = [1, -1, 1, -1];  % BPSK信号，功率为1
ebno_db = 3;         % 3dB的Eb/N0

% 使用自定义函数
y1 = custom_awgn(x, ebno_db);

% 对比内置函数
y2 = awgn(x, ebno_db);

fprintf('自定义函数输出: [%.3f %.3f %.3f %.3f]\n', y1);
fprintf('内置函数输出:   [%.3f %.3f %.3f %.3f]\n', y2);