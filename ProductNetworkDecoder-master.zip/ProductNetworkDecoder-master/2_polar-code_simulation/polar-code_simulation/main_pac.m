%polar encoder and SC, BP , SCAN decoder for awgn channel
%panzhipeng
clc,
clear all;
global PACparams;   % ���������
global c;
addpath('PACcodes');% �Զ�����·��

N = 128;
K = 48;
crc_size = 16;
Rc = K/N;
modu_model = 1;   % 1 for BPSK 
% M = 2.^modu_model;
chanModel = 1; % 1 for AWGN or 2 for rayleigh fading 
ebn0 = 5;

% SNR = ebn0 + 10*log10(Rc*Rm) + 10*log10(2); %ʵ���ź�+ 10*log10(2)
SNR = ebn0;
SNR_num = 10.^(SNR/10);

design_snr_dB = 0;%parameter for constucted polar code using BA construction method
sigma = 0.90;%parameter for constucted polar code using GA construction method


decoding_method = 3; % 0---SC  1---BP  2---SCAN  3---SCL 4---SSC;
construction_method = 1; % 0---BhattaBound  1---GA

switch decoding_method
    case 0
        initPAC(N,K,construction_method,design_snr_dB,sigma,crc_size);        
    case 1
        bp_iter_num = input('input the iternum of the BP: at least 40 \n');       
        initPAC(N,K,construction_method,design_snr_dB,sigma,crc_size);
    case 2
        scan_iter_num = input('input the iternum of the SCAN: at least 1 \n');
        initPAC(N,K,construction_method,design_snr_dB,sigma,crc_size);
    case 3
        scl_list_size = 32; %input('input the list size of the SCL: at least 1 \n');
        initPAC(N,K,construction_method,design_snr_dB,sigma,crc_size);
    case 4
        initPAC(N,K,construction_method,design_snr_dB,sigma,crc_size);
        [decoder_tree_initial, G_set, B_set] = intial_tree_G( );

    otherwise
        disp('invalid input!!!');
        bp_iter_num = 60;
        scan_iter_num = 8;
        scl_list_size = 4;
        crc_size = 0;
end



n = PACparams.n;
F = [1 0;1 1];
B=1;
for ii=1:n
    B = kron(B,F);
end
F_kron_n = B;

BER   = zeros(1,length(ebn0));
Nerr = zeros(1,length(ebn0));
Nbits = zeros(1,length(ebn0));

BLER   = zeros(1,length(ebn0));
NBLerr = zeros(1,length(ebn0));
NBL = zeros(1,length(ebn0));

maxNumErrs = 1e3;
maxNumBits = 1e7;
c = [1 1 1 1 1 1 1];
for j = 1:length(ebn0)
    
	fprintf('\n Now running:%f  [%d of %d] \n\t Iteration-Counter: %53d',ebn0(j),j,length(ebn0),0);
    while ((Nerr(j) < maxNumErrs) && (Nbits(j) < maxNumBits))
        info = randi([0 1],1,K);
        % ��������
        u = ConvolutionEncoder(info,c);
        % polar code����
        [tx_waveform,chanGain] = polarTransform(u,F_kron_n,modu_model,chanModel);
       
        rx_waveform = awgn(tx_waveform,SNR(j));
        
        llr = initia_llr(rx_waveform,modu_model,SNR(j),chanGain);
              	
	
        switch decoding_method
            case 0
                [u_llr,vhat] = PAC_SC_decode(llr,c);
            case 1
                [u_llr,~] = polar_BP_decode(llr,bp_iter_num);
            case 2
                [u_llr,~] = polar_SCAN_decode(llr,scan_iter_num);
            case 3
                [u_llr,vhat] = PAC_SCL_decode(llr,scl_list_size);      
            case 4
                u_hard_decision = polar_SSC_decode(decoder_tree_initial, G_set, B_set,llr);
                u_llr = 1-2*u_hard_decision;
        end
        
        if PACparams.crc_size
            info_crc_hat = vhat(PACparams.FZlookup == -1);
            info_hat = info_crc_hat (1:PACparams.K);
        else
            info_hat = vhat(PACparams.FZlookup == -1);
        end
        
 		nfails = sum(info_hat ~= info);   
        Nerr(j) = Nerr(j) + nfails;
        Nbits(j) = Nbits(j) + K;
        
        NBLerr(j) = NBLerr(j) + (nfails>0);
        NBL(j) = NBL(j)+ 1;
    end
    BER(j) = Nerr(j)./Nbits(j);
    BLER(j) = NBLerr(j)./NBL(j)
    
    if BLER(j)< 1e-3
        maxNumErrs = maxNumErrs*(1e-2);
    elseif BLER(j)<1e-4
        maxNumErrs = maxNumErrs*(1e-1);
    end
end

figure,
semilogy(SNR,BER,'-*');
xlabel ('EbN0');
ylabel ('BER');
legend('5g_nr_ldpc');

figure,
semilogy(SNR,BLER,'-*');
xlabel ('EbN0');
ylabel ('BLER');
legend('5g_nr_ldpc');

