%polar encoder and SC, BP , SCAN decoder for awgn channel
%panzhipeng
clc,
clear all;
global PCparams;
addpath('function');

N = 128;
K = 64;
Rc = K/N;
modu_model = 1;   % 1 for BPSK, 2 for QPSK
M = 2.^modu_model;
chanModel = 1; % 1 for AWGN or 2 for rayleigh fading 
ebn0 = 0:1:6;

% SNR = ebn0 + 10*log10(Rc*Rm) + 10*log10(2); %ʵ���ź�+ 10*log10(2)
SNR = ebn0;
SNR_num = 10.^(SNR/10);

design_snr_dB = 0;%parameter for constucted polar code using BA construction method
sigma = 0.9;%parameter for constucted polar code using GA construction method


decoding_method = 3; % 0---SC  1---BP  2---SCAN  3---SCL 4---SSC;
construction_method = 1; % 0---BhattaBound  1---GA

switch decoding_method
    case 0
        crc_size = 0;
        initPC(N,K,construction_method,design_snr_dB,sigma,crc_size);
        
    case 1
        bp_iter_num = input('input the iternum of the BP: at least 40 \n');
        crc_size = 0;
        initPC(N,K,construction_method,design_snr_dB,sigma,crc_size);
    case 2
        scan_iter_num = input('input the iternum of the SCAN: at least 1 \n');
        crc_size = 0;
        initPC(N,K,construction_method,design_snr_dB,sigma,crc_size);
    case 3
        scl_list_size = 32; %input('input the list size of the SCL: at least 1 \n');
        crc_size = 16; %input('input the crc size of the SCL: at least 0 \n');
        initPC(N,K,construction_method,design_snr_dB,sigma,crc_size);
    case 4
        crc_size = 0;
        initPC(N,K,construction_method,design_snr_dB,sigma,crc_size);
        [decoder_tree_initial, G_set, B_set] = intial_tree_G( );

    otherwise
        disp('invalid input!!!');
        bp_iter_num = 60;
        scan_iter_num = 8;
        scl_list_size = 4;
        crc_size = 0;
end



n = PCparams.n;
F = [1 0;1 1];
B=1;
for ii=1:n
    B = kron(B,F);
end
F_kron_n = B;

BER   = zeros(1,length(ebn0));
Nerr = zeros(1,length(ebn0));
Nbits = zeros(1,length(ebn0));

BLER   = zeros(1,length(ebn0));
NBLerr = zeros(1,length(ebn0));
NBL = zeros(1,length(ebn0));

maxNumErrs = 100;
maxNumBlocks = 1000;  % ��������Ŀ���
maxNumBits = maxNumBlocks*K;
for j = 1:length(ebn0)
    
	fprintf('\n Now running:%f  [%d of %d] \n\t Iteration-Counter: %53d',ebn0(j),j,length(ebn0),0);
    while ((Nerr(j) < maxNumErrs) && (Nbits(j) < maxNumBits))
        u = randi([0 1],1,K);  %�����źţ���������
        [tx_waveform,chanGain] = polar_codes_encoder(u,F_kron_n,modu_model,chanModel);  %���������
       
        rx_waveform = awgn(tx_waveform,SNR(j));
        
        llr = initia_llr(rx_waveform,modu_model,SNR(j),chanGain);
              	
	
        switch decoding_method   %�������
            case 0
                [u_llr] = polar_SC_decode(llr);
            case 1
                [u_llr,~] = polar_BP_decode(llr,bp_iter_num);
            case 2
                [u_llr,~] = polar_SCAN_decode(llr,scan_iter_num);
            case 3
                [u_llr] = polar_SCL_decode(llr,scl_list_size);      
            case 4
                u_hard_decision = polar_SSC_decode(decoder_tree_initial, G_set, B_set,llr);
                u_llr = 1-2*u_hard_decision;
        end
        if PCparams.crc_size
            uhat_crc_llr = u_llr(PCparams.FZlookup == -1)';
            uhat_llr = uhat_crc_llr (1:PCparams.K);
        else
            uhat_llr = u_llr(PCparams.FZlookup == -1)';
        end
		uhat = zeros(1,K);
        uhat(uhat_llr<=0) =1;
		nfails = sum(uhat ~= u);   
        Nerr(j) = Nerr(j) + nfails;
        Nbits(j) = Nbits(j) + K;
        
        NBLerr(j) = NBLerr(j) + (nfails>0);
        NBL(j) = NBL(j)+ 1;
    end
    BER(j) = Nerr(j)./Nbits(j);
    BLER(j) = NBLerr(j)./NBL(j)
end

figure,
semilogy(SNR,BER,'-*');
xlabel ('EbN0');
ylabel ('BER');
legend('5g_nr_ldpc');

figure,
semilogy(SNR,BLER,'-*');
xlabel ('EbN0');
ylabel ('BLER');
legend('5g_nr_ldpc');




