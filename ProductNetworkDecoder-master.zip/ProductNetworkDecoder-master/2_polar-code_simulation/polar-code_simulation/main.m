%polar encoder and SC, BP , SCAN decoder for awgn channel
%panzhipeng
clc,
clear all;
global PCparams;
global PACparams;   % ���������
global c;
c = [1 1 1 1 1 1 1];
addpath('PACcodes');% �Զ�����·��
addpath('function');

N = 128;
K = 64;
Rc = K/N;
modu_model = 1;   % 1 for BPSK 
M = 2.^modu_model;
chanModel = 1; % 1 for AWGN or 2 for rayleigh fading 
scl_list_size = 32; %input('input the list size of the SCL: at least 1 \n');
crc_size = 16; %input('input the crc size of the SCL: at least 0 \n');

ebn0 = 0:1:5;

% SNR = ebn0 + 10*log10(Rc*Rm) + 10*log10(2); %ʵ���ź�+ 10*log10(2)
SNR = ebn0;
SNR_num = 10.^(SNR/10);

design_snr_dB = 0;%parameter for constucted polar code using BA construction method
sigma = 0.90;%parameter for constucted polar code using GA construction method

construction_method = 1; % 0---BhattaBound  1---GA
initPC(N,K,construction_method,design_snr_dB,sigma,crc_size);
initPAC(N,K,construction_method,design_snr_dB,sigma,crc_size);

n = PCparams.n;
F = [1 0;1 1];
B=1;
for ii=1:n
    B = kron(B,F);
end
F_kron_n = B;

BLER_pc = zeros(1,length(ebn0));
NBLerr_pc = zeros(1,length(ebn0));
NBL_pc = zeros(1,length(ebn0));

BLER_pac   = zeros(1,length(ebn0));
NBLerr_pac  = zeros(1,length(ebn0));
NBL_pac = zeros(1,length(ebn0));

maxNumErrs = 1e4;
maxNum = 1e4;
for j = 1:length(ebn0)
    
	fprintf('\n Now running:%f  [%d of %d] \n\t Iteration-Counter: %53d',ebn0(j),j,length(ebn0),0);
    while ((NBLerr_pc(j) < maxNumErrs) && (NBL_pc(j) < maxNum))
        u = randi([0 1],1,K);
        
        % ���������
        [tx_waveform,chanGain] = polar_codes_encoder(u,F_kron_n,modu_model,chanModel);
        rx_waveform = awgn(tx_waveform,SNR(j));
        llr = initia_llr(rx_waveform,modu_model,SNR(j),chanGain);       	
        [u_llr] = polar_SCL_decode(llr,scl_list_size);
        if PCparams.crc_size
            uhat_crc_llr = u_llr(PCparams.FZlookup == -1)';
            uhat_llr = uhat_crc_llr (1:PCparams.K);
        else
            uhat_llr = u_llr(PCparams.FZlookup == -1)';
        end
		uhat = zeros(1,K);
        uhat(uhat_llr<=0) =1;
		nfails = sum(uhat ~= u);         
        NBLerr_pc(j) = NBLerr_pc(j) + (nfails>0);
        NBL_pc(j) = NBL_pc(j)+ 1;
        
        % �������������
        u1 = ConvolutionEncoder(u,c);
        [tx_waveform,chanGain] = polarTransform(u1,F_kron_n,modu_model,chanModel); 
        rx_waveform = awgn(tx_waveform,SNR(j));  
        llr = initia_llr(rx_waveform,modu_model,SNR(j),chanGain);  
        [~,vhat] = PAC_SCL_decode(llr,scl_list_size);
        if PACparams.crc_size
            info_crc_hat = vhat(PACparams.FZlookup == -1);
            info_hat = info_crc_hat (1:PACparams.K);
        else
            info_hat = vhat(PACparams.FZlookup == -1);
        end
        
 		nfails = sum(info_hat ~= u);        
        NBLerr_pac(j) = NBLerr_pac(j) + (nfails>0);
        NBL_pac(j) = NBL_pac(j)+ 1;
    end
    BLER_pc(j) = NBLerr_pc(j)./NBL_pc(j)
    BLER_pac(j) = NBLerr_pac(j)./NBL_pac(j)
end

figure,
semilogy(SNR,BLER_pc,'-*');
xlabel ('EbN0');
ylabel ('BER');
legend('PC');

figure,
semilogy(SNR,BLER_pac,'-*');
xlabel ('EbN0');
ylabel ('BLER');
legend('PAC');

