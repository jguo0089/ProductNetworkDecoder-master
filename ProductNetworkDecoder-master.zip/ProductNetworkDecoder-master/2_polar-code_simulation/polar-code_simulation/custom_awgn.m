function y_whole = custom_awgn(x_whole, ebno_db)
    % 自定义AWGN信道函数（不使用内置awgn）
    % 输入：
    %   x_whole: 输入信号
    %   ebno_db: Eb/N0 in dB
    % 输出：
    %   y_whole: 加噪后的信号
    
    % 计算SNR线性值
    snr_linear = 10^(ebno_db / 10);
    
    % 计算噪声方差（假设信号功率为1）
    sigma2 = 1.0 / snr_linear;
    sigma = sqrt(sigma2);
    
    % 生成高斯噪声
    noise = sigma * randn(size(x_whole));
    
    % 输出加噪信号
    y_whole = x_whole + noise;
end