import numpy as np
from itertools import combinations

def repocessor_Original(oHD, Gs, n_bch, k_bch, currentBest, minDis, aRo):
    n = n_bch
    k = k_bch
    m = 3

    checkNum = 0
    rHD = oHD[:k]

    for iter in range(1, m + 1):
        errDis = np.array(list(combinations(range(k), iter)))
        sz = errDis.shape[0]

        rHDD = np.repeat(rHD[np.newaxis, :], sz, axis=0)
        oHHD = np.repeat(oHD[np.newaxis, :], sz, axis=0)
        aA = np.repeat(aRo[np.newaxis, :], sz, axis=0)

        temErr = np.zeros((sz, k))
        for i in range(sz):
            temErr[i, errDis[i, :]] = 1
        temInf = np.mod(rHDD + temErr, 2)
        temCode = np.mod(np.dot(temInf, Gs), 2)
        temDis = np.sum(np.abs(oHHD - temCode) * aA, axis=1)

        currentDis, I = np.min(temDis), np.argmin(temDis)

        if currentDis < minDis:
            minDis = currentDis
            currentBest = temCode[I, :]

        checkNum += sz

    return currentBest, checkNum