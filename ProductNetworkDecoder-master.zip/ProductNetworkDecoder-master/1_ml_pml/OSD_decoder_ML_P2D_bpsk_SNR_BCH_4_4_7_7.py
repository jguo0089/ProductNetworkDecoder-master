# # general imports


# # 在所有导入之前应用全局补丁
# import os
# import sys
# import pandas as pd
# os.environ['DRJIT_LIBLLVM_PATH'] = 'C:/Program Files/LLVM15/bin/LLVM-C.dll'
# os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

# # 全局修补方案：在sys.modules中预先注册虚拟RT模块
# def setup_sionna_patch():
#     """在导入任何使用sionna的模块之前设置补丁"""
#     import types
#     import importlib
    
#     # 创建虚拟的RT相关模块
#     rt_modules = [
#         'sionna.rt',
#         'sionna.rt.scene', 
#         'sionna.rt.antenna_array',
#         'sionna.rt.utils',
#         'sionna.rt.utils.electromagnetics',
#         'sionna.rt.utils.misc'
#     ]
    
#     for module_name in rt_modules:
#         if module_name not in sys.modules:
#             # 创建虚拟模块
#             dummy_module = types.ModuleType(module_name)
#             sys.modules[module_name] = dummy_module
            
#             # 为某些模块添加必要的虚拟属性
#             if module_name == 'sionna.rt.scene':
#                 dummy_module.load_scene = lambda *args, **kwargs: None
#                 dummy_module.Scene = type('Scene', (), {})
#             elif module_name == 'sionna.rt.antenna_array':
#                 dummy_module.AntennaArray = type('AntennaArray', (), {})
#             elif module_name == 'sionna.rt.utils':
#                 dummy_module.rotate = lambda *args, **kwargs: None
#             elif module_name == 'sionna.rt.utils.misc':
#                 # 创建虚拟的complex_sqrt函数
#                 def dummy_complex_sqrt(x):
#                     return x
#                 dummy_module.complex_sqrt = dummy_complex_sqrt
    
#     print("✓ Sionna RT模块补丁已应用")

# # 应用补丁
# setup_sionna_patch()

# import numpy as np
# import matplotlib.pyplot as plt

# try:
#     # 现在应该可以安全导入sionna和gnn模块了
#     from sionna.fec.utils import load_parity_check_examples, LinearEncoder, gm2pcm
#     from sionna.utils.plotting import PlotBER
#     from sionna.fec.ldpc import LDPCBPDecoder
#     print("✓ Sionna FEC components imported successfully")
# except Exception as e:
#     print(f"✗ Sionna import failed: {e}")

# try:
#     from gnn import * # load GNN functions
#     print("✓ GNN module imported successfully")
# except Exception as e:
#     print(f"✗ GNN import failed: {e}")
#     print("如果仍然失败，可能需要修改gnn.py文件")

# try:
#     from wbp import * # load weighted BP functions  
#     print("✓ WBP module imported successfully")
# except Exception as e:
#     print(f"✗ WBP import failed: {e}")

# # 验证LLVM设置
# llvm_path = 'C:/Program Files/LLVM15/bin/LLVM-C.dll'
# print(f"LLVM-C.dll exists: {os.path.exists(llvm_path)}")

# print("补丁应用完成，可以继续运行其余代码")


# general imports
import tensorflow as tf
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# load required Sionna components
from sionna.fec.utils import load_parity_check_examples, LinearEncoder, gm2pcm
from sionna.utils.plotting import PlotBER
from sionna.fec.ldpc import LDPCBPDecoder, LDPC5GEncoder, LDPC5GDecoder
from TransferG_systematic_form import to_systematic_form, validate_ldpc_matrices
from OSD_DecoderBCH import OSD_DecoderBCH

from sionna.utils import BinarySource, ebnodb2no
from sionna.mapping import Mapper, Demapper
from sionna.channel import AWGN
from sionna.utils.metrics import compute_ber

# from BP_snr_two_model_update_v1 import * # load GNN functions
# from wbp import * # load weighted BP functions
from bina_encoding import row_LinearEncoder
from bina_encoding import col_LinearEncoder
# from ldpc_5g_encoding_row import LDPC5GEncoder_row
# from ldpc_5g_encoding_col import LDPC5GEncoder_col

gpus = tf.config.list_physical_devices('GPU')
print('Number of GPUs available :', len(gpus))

params={
    # --- Code Parameters ---
        "code": "reg-LDPC",
        "n_des1": 12, # target codeword length (code generation may slightly increase n)
        "v1": 2, # VN degree
        "c1": 6, # VN degree
        "n_des2": 12, # target codeword length (code generation may slightly increase n)
        "v2": 2, # VN degree
        "c2": 6, # VN degree
        "k1":2,
        "k2":32,
        "n1":3,
        "n2":48,

    # --- GNN Architecture ----
        "num_embed_dims": 16,
        "num_msg_dims": 16,
        "num_hidden_units": 64,
        "num_mlp_layers": 2,
        "num_iter": 5,
        "reduce_op": "mean",
        "activation": "tanh",
        "clip_llr_to": None,
        "use_attributes": False,
        "node_attribute_dims": 0,
        "msg_attribute_dims": 0,
        "return_infobits": False,
        "use_bias": True,        
    # --- Training ---- # 
        "batch_size": [128, 128, 128], # bs, iter, lr must have same dim
        "train_iter": [50000, 200000, 300000],
        "learning_rate": [2e-4, 1e-4, 1e-5],
        "ebno_db_train": [0., 5.],
        "ebno_db_eval": 2,          
        "batch_size_eval": 512, # batch size only used for evaluation during training
        "eval_train_steps": 1, # evaluate model every N iters
    # --- Log ----
        "save_weights_iter": 10000, # save weights every X iters
        "run_name": "LDPC_reg_8_8_iter5_JT6", # name of the stored weights/logs
        "save_dir": "results/", # folder to store results
        "JT_number": 6,
    # --- MC Simulation parameters ----
        "eval_dec_iter": 20, # number of decoding iters to evaluate
        "mc_iters": 100,
        "mc_batch_size": 1000,
        "num_target_block_errors": 1000,
        "ebno_db_min": 0.,
        "ebno_db_max": 5.,
        "ebno_db_stepsize": 1,
        "eval_ns": [100, 500],        
    # --- Weighted BP parameters ----
        "simulate_wbp": True, # simulate weighted BP as baseline
        "wbp_batch_size" : [1000, 1000, 1000],
        "wbp_train_iter" : [300, 2000, 2000],
        "wbp_learning_rate" : [1e-2, 1e-3, 1e-3],
        "wbp_ebno_train" : [2.5, 3., 3.5],
        "wbp_ebno_val" : 5., # validation SNR during training
        "wbp_batch_size_val" : 2000,
        "wbp_clip_value_grad" : 10, 
}





#pcm = np.load('custom_small_ldpc_H_8_12.npy')
# G_row = np.load('irregular_ldpc_G_16_8ird.npy')

# G_col=np.load('irregular_ldpc_G_20_8ird.npy')

#G_row = np.load('G_k7n15.npy')
# G_row = np.load('G_k7n15.npy', allow_pickle=True)

# G_col=np.load('G_k7n15.npy', allow_pickle=True)

# G_row = np.loadtxt('4_4_4/G_pr_k8n12low.txt')
# G_col = np.loadtxt('4_4_4/G_pr_k8n16low.txt')


# G_row = np.load('LDPC/ldpc_G_12_8smallenew813.npy')
# G_col = np.load('LDPC/ldpc_G_12_8smallenew813.npy')

# G_row=np.load('LDPC/ldpc_G_3_2_911.npy')
# #pcm_row=pcm_row.reshape(1,-1)##转换成1行n列
# #G_row = np.loadtxt('PR/G_pr_k4n5.txt')
# #G_col = np.loadtxt('PR/G_pr_k16n28.txt')

# # G_col = np.loadtxt('PR/G_pr_k16n28.txt')

# #G_col=np.load('LDPC/ldpc_G_28_16_913.npy')
# G_col=np.load('LDPC/ldpc_G_48_32_916.npy')
# G_row = np.load('LDPC/ldpc_G_12_8smallenew813.npy')
# G_col = np.loadtxt('PR/G_pr_k8n12.txt')

# G_row = np.load('5G_LDPC/gm_5g_ldpc_k8_n12.npy')
# #G_col = np.load('5G_LDPC/gm_5g_ldpc_k8_n12.npy')
# G_col = np.load('5G_LDPC/gm_5g_ldpc_k8_n12.npy')

k1=4
k2=4

n1=7
n2=7
# pcm_row = np.loadtxt('PR/H_pr_k8n12.txt')
# G_row = np.loadtxt('PR/G_pr_k8n12.txt')
#
# pcm_col=np.loadtxt('PR/H_pr_k8n16.txt')
# G_col=np.loadtxt('PR/G_pr_k8n16.txt')



pcm_row=np.loadtxt('BCH/BCH_k4_n7_pcm.txt')
G_row=np.loadtxt('BCH/BCH_4_7_G.txt')
#pcm_row=pcm_row.reshape(1,-1)##转换成1行n列
pcm_col=np.loadtxt('BCH/BCH_k4_n7_pcm.txt')
G_col=np.loadtxt('BCH/BCH_4_7_G.txt')
# G_col=np.loadtxt('BCH/BCH_15_7_G.txt')
# pcm_col=np.loadtxt('BCH/BCH_k7n15_pcm.txt')


#
#
# k1=8
# k2=8
#
# n1=12
# n2=16


# G_row = np.loadtxt('PR/G_pr_k8n10.txt')
# G_col = np.loadtxt('PR/G_pr_k8n10.txt')


# k1=2
# k2=32

# n1=3
# n2=48


# pcm_row, k1, n1, coderate = generate_reg_ldpc(v=params["v1"], 
#                                             c=params["c1"],  
#                                             n=params["n_des1"], 
#                                             allow_flex_len=True, 
#                                             verbose=True)

encoder_row = row_LinearEncoder(G_row, is_pcm=False)
params["k1"] = k1
params["n1"] = n1





encoder_col = col_LinearEncoder(G_col, is_pcm=False)

params["k2"] = k2
params["n2"] = n2



k1_new=k1
n1_new=n1
k2_new=k2
n2_new=n2


ITER = 10000
#num_flag = np.zeros(ITER)




#SNR_vec = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], dtype=np.float32)  # SNR range
SNR_vec = np.arange(0, 7, 1, dtype=np.float32)
#print(SNR_vec.dtype)
SNR_len = len(SNR_vec)
ber_avg_record = np.zeros(SNR_len)  # 新增：用于存储每个SNR下的平均BER

    

tot_idx=[]



num_flag = np.zeros((ITER, SNR_len))  # 用于存储每个ITER和SNR下的flag
ber_record = np.zeros((ITER, SNR_len))  # 用于记录每个ITER和SNR下的BER
num_bits_per_symbol=2
mapper = Mapper("qam", num_bits_per_symbol)
demapper = Demapper("app", "qam", num_bits_per_symbol)
#channel = AWGN()
channel = AWGN(dtype=tf.complex64)  # or tf.complex128


@tf.function
def compute_ber_tf(c_col, c_hat):
    return compute_ber(c_col, c_hat)

def generate_matrix(k1, k2, n1, n2, encoder_row, encoder_col):
    gm_rows = []
    
    for index in range(k2 * k1):
        # Create one-hot encoding
        b = tf.one_hot(index, depth=k2*k1, dtype=tf.float32)
        # Add batch dimension
        b = tf.expand_dims(b, 0)
        # Reshape b to [1, k2, k1]
        b = tf.reshape(b, [1, k2, k1])

        # Row encoding
        row_codewords = encoder_row(b)
        c_row = tf.reshape(row_codewords, [1, k2 * n1])

        # Column encoding
        col_codewords = encoder_col(b)
        last_cols = col_codewords[:, k2:, :]
        # Only take the parity part of the columns
        c_col_last = tf.reshape(last_cols, [1, (n2-k2) * k1])

        # Combine all codewords from rows and columns
        c_whole = tf.concat([c_row, c_col_last], axis=1)
        
        # Add c_whole to the list of rows for the generator matrix
        gm_rows.append(c_whole[0])  # Remove batch dimension
    
    # Stack all rows into a matrix
    gm = tf.stack(gm_rows)
    
    return gm
    
gm = generate_matrix(k1, k2, n1, n2, encoder_row, encoder_col)


G_standard  =  gm.numpy()


for tot_idx in range(ITER):

    binary_source = BinarySource()
    b = binary_source([1, params["k2"], params["k1"]])
  
   
    #行编码
    row_codewords = encoder_row(b)
    c_row = tf.reshape(row_codewords, [1, k2 * n1])

    
    #列编码
    col_codewords = encoder_col(b)
    last_cols= col_codewords[:, k2:, :]
    #只取列的校验部分
    c_col_last = tf.reshape(last_cols, [1, (n2-k2) * k1])

    #合并行列所有码字
    c_whole = tf.concat([c_row, c_col_last], axis=1)

    print('c_whole shape:', c_whole.shape)
    #调制
   

    x_whole = (-1) ** c_whole
    # 或者方式2：使用更直接的映射
    # x_whole = 1 - 2 * tf.cast(c_whole, tf.float32)
    n_whole = c_whole.shape[1]
    k_whole = k1_new * k2_new
    
    # 计算码率
    coderate = k_whole / n_whole

   
 
    for SNR_idx in range(SNR_len):
        print(f'Iteration: {tot_idx + 1}, SNR Index: {SNR_idx + 1}')

        #所有码字进入信道
        # no = ebnodb2no(SNR_vec[SNR_idx], 
        #               num_bits_per_symbol=1,  # BPSK
        #               coderate=coderate)
        
        # # AWGN信道
        # noise = tf.sqrt(no/2) * tf.random.normal(tf.shape(x_whole))
        # y_whole = x_whole + noise

        # # 计算LLR (Sionna风格: σ² = N0)
        # llr = 4 * y_whole / no

        snr_linear = tf.pow(10.0, SNR_vec[SNR_idx] / 10.0)

        # 计算噪声方差
        sigma2 = 1.0 / snr_linear
        sigma = tf.sqrt(sigma2)

        # 生成高斯噪声
        noise = sigma * tf.random.normal(tf.shape( x_whole), mean=0.0, stddev=1.0)

        y_whole = x_whole + noise

        llr = 2 * y_whole / sigma2

       

        
        # 转换为numpy用于OSD解码
        llr_new = llr.numpy()
        llr_new1 = llr_new.flatten()  # 展平成一维数组

        # 译码 (注意：OSD解码器可能需要负的LLR)
        cEst, checkNum = OSD_DecoderBCH(llr_new1, G_standard, n_whole, k_whole)

       

        
        ber = compute_ber(c_whole, cEst).numpy()
        print('ber:', ber)
        ber_record[tot_idx, SNR_idx] = ber
        # ber_record[tot_idx, SNR_idx] = ber  # 记录BER
       

for SNR_idx in range(SNR_len):
    ber_avg_record[SNR_idx] = np.mean(ber_record[:, SNR_idx])  # 修改：将计算平均BER的代码移到外层循环中

    
# 计算每个SNR值的平均BLER
BLER_array = np.sum(ber_record > 0, axis=0) / ITER

# 如果您需要一个列表形式的BLER
BLER_list = BLER_array.tolist()

# 打印BLER结果
print("BLER List:", BLER_list)
print("BER List:",  ber_avg_record)

df = pd.DataFrame({'ebno_db': SNR_vec, 'BLER': BLER_list, 'BER': ber_avg_record})

# 将DataFrame保存到CSV文件
df.to_csv('BCH_2D_BLER_4_7_7_15results.csv', index=False)

#input("按任意键继续...")