import numpy as np
import matplotlib.pyplot as plt

def to_systematic_form(G):
    """
    Convert a generator matrix to systematic form [I|P].
    
    Parameters:
    G (numpy.ndarray): The generator matrix to convert.
    
    Returns:
    numpy.ndarray: The generator matrix in systematic form.
    """
    k, n = G.shape
    G = G.astype(float)  # Convert to float for Gaussian elimination
    
    # Perform Gaussian elimination
    for i in range(k):
        # Find pivot
        pivot = i
        while pivot < n and G[i, pivot] == 0:
            pivot += 1
        if pivot == n:
            raise ValueError("Generator matrix is not full rank")
        
        # Swap columns if necessary
        if pivot != i:
            G[:, [i, pivot]] = G[:, [pivot, i]]
        
        # Normalize the pivot row
        G[i] = G[i] / G[i, i]
        
        # Eliminate in other rows
        for j in range(k):
            if i != j:
                G[j] = G[j] - G[j, i] * G[i]
    
    # Round to remove floating point errors and convert back to int
    G = np.round(G).astype(int)
    
    # Apply modulo 2 to ensure binary
    G = G % 2
    
    return G



def validate_ldpc_matrices(pcm, G):
    """
    Validate the parity-check matrix (PCM) and generator matrix (G) for LDPC coding.
    
    Parameters:
    pcm (numpy.ndarray): The parity-check matrix
    G (numpy.ndarray): The generator matrix
    
    Returns:
    bool: True if the matrices are valid, False otherwise
    str: A message explaining the validation result
    """
    
    # Convert inputs to numpy arrays if they're not already
    pcm = np.array(pcm)
    G = np.array(G)
    
    # Check 1: Dimensions
    m, n = pcm.shape
    k, n_g = G.shape
    
    if n != n_g:
        return False, f"Mismatch in code length: PCM suggests n={n}, G suggests n={n_g}"
    
    if k != n - m:
        return False, f"Mismatch in dimensions: k (from G) = {k}, but n-m = {n-m}"
    
    # Check 2: Binary matrices
    if not np.all(np.logical_or(pcm == 0, pcm == 1)):
        return False, "PCM is not a binary matrix"
    
    if not np.all(np.logical_or(G == 0, G == 1)):
        return False, "G is not a binary matrix"
    
    # Check 3: G * H^T = 0 (mod 2)
    product = np.dot(G, pcm.T) % 2
    if not np.all(product == 0):
        return False, "G * H^T is not zero (mod 2)"
    
    # Check 4: Rank of G
    if np.linalg.matrix_rank(G) != k:
        return False, f"G does not have full rank (rank={np.linalg.matrix_rank(G)}, should be {k})"
    
    # Check 5: Rank of H
    if np.linalg.matrix_rank(pcm) != m:
        return False, f"H does not have full rank (rank={np.linalg.matrix_rank(pcm)}, should be {m})"
    
    return True, "The PCM and G matrices are valid for LDPC coding"

# Your original generator matrix
G_original = np.array([
    [1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0],
    [1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0]
])

# Convert to systematic form
G_systematic = to_systematic_form(G_original)

# print("Generator matrix in systematic form:")
# print(G_systematic)

# Verify that it's in the form [I|P]
k, n = G_systematic.shape
I = G_systematic[:, :k]
P = G_systematic[:, k:]

# print("\nIs the left part an identity matrix?", np.array_equal(I, np.eye(k, dtype=int)))
# print("Shape of P:", P.shape)

def generate_reg_ldpc(v, c, n, allow_flex_len=True, verbose=True):
    """Generate random regular (v,c) LDPC code.

    This functions generates a random LDPC parity-check matrix of length ``n``
    where each variable node (VN) has degree ``v`` and each check node (CN) has
    degree ``c``. Please note that the LDPC code is not optimized to avoid
    short cycles. For encoding, the :class:`~sionna.fec.utils.LinearEncoder`
    layer can be used.

    Input
    -----
    v : int
        Desired variable node (VN) degree.

    c : int
        Desired check node (CN) degree.

    n : int
        Desired codeword length.

    allow_flex_len: bool
        Defaults to True. If True, the resulting codeword length can be
        (slightly) increased.

    verbose : bool
        Defaults to True. If True, code parameters are printed.

    Output
    ------
    (pcm, k, n, coderate):
        Tuple:

    pcm: ndarray
        NumPy array of shape `[n-k, n]` containing the parity-check matrix.

    k: int
        Number of information bits per codeword.

    n: int
        Number of codewords bits.

    coderate: float
        Coderate of the code.


    Note
    ----
    This algorithm only works for regular node degrees. For state-of-the-art
    bit-error-rate performance, usually one needs to optimize irregular LDPC
    codes.
    """

    # check input values for consistency
    assert isinstance(allow_flex_len, bool), \
                                    'allow_flex_len must be bool.'

    # allow slight change in n to keep num edges
    # from CN and VN perspective an integer
    if allow_flex_len:
        for n_mod in range(n, n+2*c):
            if np.mod((v/c) * n_mod, 1.)==0:
                n = n_mod
                if verbose:
                    print("Changing n to: ", n)
                break

    # calculate number of nodes
    coderate = 1 - (v/c) # to be checked
    n_v = n
    n_c = int((v/c) * n)
    k = n_v - n_c

    # generate sockets
    v_socks = np.tile(np.arange(n_v),v)
    c_socks = np.tile(np.arange(n_c),c)
    if verbose:
        print("Number of edges (VN perspective): ", len(v_socks))
        print("Number of edges (CN perspective): ", len(c_socks))
    assert len(v_socks) == len(c_socks), "Number of edges from VN and CN " \
        "perspective does not match. Consider to (slightly) change n."

    # apply random permutations
    np.random.shuffle(v_socks)
    np.random.shuffle(c_socks)

    # and generate matrix
    pcm = np.zeros([n_c, n_v])

    idx = 0
    shuffle_max = 1000 # stop if no success
    shuffle_counter = 0
    cont = True
    while cont:
        # if edge is available, take it
        if pcm[c_socks[idx],v_socks[idx]]==0:
            pcm[c_socks[idx],v_socks[idx]] = 1
            idx += 1 # and go to next socket
            shuffle_counter = 0 # reset counter
            if idx==len(v_socks):
                cont=False
        else: # shuffle sockets
            shuffle_counter += 1
            if shuffle_counter<shuffle_max:
                np.random.shuffle(v_socks[idx:])
                np.random.shuffle(c_socks[idx:])
            else:
                print("Stopping - no solution found!")
                cont=False

    v_deg = np.sum(pcm, axis=0)
    c_deg = np.sum(pcm, axis=1)

    #assert((v_deg==v).all()), "VN degree not always v."
    #assert((c_deg==c).all()), "CN degree not always c."

    if verbose:
        print(f"Generated regular ({v},{c}) LDPC code of length n={n}")
        print(f"Code rate is r={coderate}.")
        plt.spy(pcm)

    return pcm, k, n


def pcm2gm(pcm, verify_results=True):
    r"""Generate the generator matrix for a given parity-check matrix.

    This function brings ``pcm`` :math:`\mathbf{H}` in its systematic form and
    uses the following relation to find the generator matrix
    :math:`\mathbf{G}` in GF(2)

    .. math::

        \mathbf{G} = [\mathbf{I} |  \mathbf{M}]
        \Leftrightarrow \mathbf{H} = [\mathbf{M} ^t | \mathbf{I}]. \tag{1}

    This follows from the fact that for an all-zero syndrome, it must hold that

    .. math::

        \mathbf{H} \mathbf{c}^t = \mathbf{H} * (\mathbf{u} * \mathbf{G})^t =
        \mathbf{H} * \mathbf{G} ^t * \mathbf{u}^t =: \mathbf{0}

    where :math:`\mathbf{c}` denotes an arbitrary codeword and
    :math:`\mathbf{u}` the corresponding information bits.

    This leads to

    .. math::

     \mathbf{G} * \mathbf{H} ^t =: \mathbf{0}. \tag{2}

    It can be seen that (1) fulfills (2) as in GF(2) it holds that

    .. math::

        [\mathbf{I} |  \mathbf{M}] * [\mathbf{M} ^t | \mathbf{I}]^t
         = \mathbf{M} + \mathbf{M} = \mathbf{0}.

    Input
    -----
    pcm : ndarray
        Binary parity-check matrix of shape `[n-k, n]`.

    verify_results: bool
        Defaults to True. If True, it is verified that the generated
        generator matrix is orthogonal to the parity-check matrix in GF(2).

    Output
    ------
    : ndarray
        Binary generator matrix of shape `[k, n]`.

    Note
    ----
    This algorithm only works if ``pcm`` has full rank. Otherwise an error is
    raised.

    """
    n = pcm.shape[1]
    k = n - pcm.shape[0]

    assert k<n, "Invalid matrix dimensions."

    # bring pcm in systematic form
    pcm_sys, c_swaps = make_systematic(pcm, is_pcm=True)

    m_mat = np.transpose(np.copy(pcm_sys[:,:k]))
    i_mat = np.eye(k)
    gm = np.concatenate((i_mat, m_mat), axis=1)

    # undo column swaps
    for l in c_swaps[::-1]: # reverse ordering when going through list
        gm[:,[l[0], l[1]]] = gm[:,[l[1], l[0]]] # swap columns

    if verify_results:
        assert verify_gm_pcm(gm=gm, pcm=pcm), \
            "Resulting parity-check matrix does not match to generator matrix."
    return gm