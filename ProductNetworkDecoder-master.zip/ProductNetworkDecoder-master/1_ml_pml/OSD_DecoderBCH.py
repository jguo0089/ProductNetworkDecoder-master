import numpy as np
from findP2_g2rref import findP2_g2rref
from repocessor_Original import repocessor_Original

def OSD_DecoderBCH(r, G, n_bch, k_bch):
    m =8
    n = n_bch
    k = k_bch

    HD = np.where(r > 0, 0, 1)
    a = np.abs(r)

    # R, P1 = np.flip(np.argsort(a))

    HD = np.where(r > 0, 0, 1)
    a = np.abs(r)

    P1 = np.argsort(a)[::-1]
    R = a[P1]

    iP1 = np.zeros(n, dtype=int)

    G_1 = np.zeros((G.shape[0], n))
    G_1[:, :n] = G[:, P1]
    y = r[P1]

    G_s, P2 = findP2_g2rref(G_1)
    P = P1[P2]

    z = y[P2]
    aRo = np.abs(z)

    iP = np.zeros(n, dtype=int)
    for i in range(n):
        iP[P[i]] = i

    oHD = HD[P]
    rHD = oHD[:k]

    c0 = np.mod(np.dot(rHD, G_s), 2)

    minDis = np.sum(np.abs(oHD - c0) * aRo)

    currentBest = c0

    if m == 0:
        checkNum = 0
    else:
        currentBest, checkNum = repocessor_Original(oHD, G_s, n_bch, k_bch, currentBest, minDis, aRo)

    cEst = currentBest[iP]

    return cEst, checkNum