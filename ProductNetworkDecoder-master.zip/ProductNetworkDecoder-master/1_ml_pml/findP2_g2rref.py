import numpy as np

def findP2_g2rref(G_1):
    K, N = G_1.shape
    P2 = np.arange(N)
    tol = max(K, N) * np.finfo(G_1.dtype).eps * np.linalg.norm(G_1, np.inf)

    i = 0
    j = 0
    jb = []
    while i < K and j < N:
        p, k = np.max(np.abs(G_1[i:, j])), np.argmax(np.abs(G_1[i:, j])) + i
        if p <= tol:
            for check in range(K, N):
                p, k = np.max(np.abs(G_1[i:, check])), np.argmax(np.abs(G_1[i:, check])) + i
                if p > tol:
                    G_1[:, [j, check]] = G_1[:, [check, j]]
                    P2[[j, check]] = P2[[check, j]]
                    break
        else:
            jb.append(j)
            G_1[[i, k], j:] = G_1[[k, i], j:]
            G_1[i, j:] = G_1[i, j:] / G_1[i, j]
            for k in range(i):
                G_1[k, j:] = np.mod(G_1[k, j:] + np.mod(G_1[k, j] * G_1[i, j:], 2), 2)
            for k in range(i + 1, K):
                G_1[k, j:] = np.mod(G_1[k, j:] + np.mod(G_1[k, j] * G_1[i, j:], 2), 2)
            i += 1
            j += 1

    return G_1, P2