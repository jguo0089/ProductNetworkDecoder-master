# SPDX-FileCopyrightText: Copyright (c) 2022 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.


##### Utility functions for graph neural networks #####

import os
import numpy as np
import tensorflow as tf
from tensorflow.keras import Model
from tensorflow.keras.layers import Layer, Dense
import pickle
from sionna.utils.metrics import compute_ber
from time import time
import warnings # ignore some internal TensorFlow warnings

# for e2e model
from sionna.utils import BinarySource, ebnodb2no,snrdb2no
from sionna.mapping import Mapper, Demapper
from sionna.channel import AWGN
from sionna.fec.ldpc import LDPC5GDecoder, LDPC5GEncoder
from bina_encoding import row_LinearEncoder
from bina_encoding import col_LinearEncoder


   

class E2EModel(tf.keras.Model):
    """End-to-end model for (GNN-)decoder evaluation.

    Parameters
    ----------
    encoder: Layer or None
        Encoder layer, no encoding applied if None.

    decoder: Layer or None
        Decoder layer, no decoding applied if None.

    k: int
        Number of information bits per codeword.

    n: int
        Codeword lengths.

    return_infobits: Boolean
        Defaults to False. If True, only the ``k`` information bits are
        returned. Must be supported be the decoder as well.

    es_no: Boolean
        Defaults to False. If True, the SNR is not rate-adjusted (i.e., Es/N0).

    Input
    -----
        batch_size: int or tf.int
            The batch_size used for the simulation.

        ebno_db: float or tf.float
            A float defining the simulation SNR.

    Output
    ------
        (c, llr):
            Tuple:

        c: tf.float32
            A tensor of shape `[batch_size, n] of 0s and 1s containing the
            transmitted codeword bits.

        llr: tf.float32
            A tensor of shape `[batch_size, n] of llrs containing estimated on
            the codeword bits.
    """

    def __init__(self, encoder, decoder, k, n, return_infobits=False, es_no=False):
        super().__init__()

        self._n = n
        self._k = k

        self._binary_source = BinarySource()
        self._num_bits_per_symbol = 2
        self._mapper = Mapper("qam", self._num_bits_per_symbol)
        self._demapper = Demapper("app", "qam", self._num_bits_per_symbol)
        self._channel = AWGN()
        self._decoder = decoder
        self._encoder = encoder
        self._return_infobits = return_infobits
        self._es_no = es_no

    @tf.function(jit_compile=True)
    def call(self, batch_size, ebno_db):

     

        # no rate-adjustment for uncoded transmission or es_no scenario
        if self._decoder is not None and self._es_no==False:
            #no = ebnodb2no(ebno_db, self._num_bits_per_symbol, self._k/self._n)
            no = snrdb2no(ebno_db)

        else: #for uncoded transmissions the rate is 1
            no = ebnodb2no(ebno_db, self._num_bits_per_symbol, 1)

        b = self._binary_source([batch_size, self._k])
        if self._encoder is not None:
            c = self._encoder(b)
        else:
            c = b
        
       

        # zero padding to support odd codeword lengths
        if self._n%2==1:
            c_pad = tf.concat([c, tf.zeros([batch_size, 1])], axis=1)
        else: # no padding
            c_pad = c
       # print('c_pad:', c_pad)
        x = self._mapper(c_pad)

        y = self._channel([x, no])
        llr = self._demapper([y, no])

        # remove zero padded bit at the end
        if self._n%2==1:
            llr = llr[:,:-1]

        # and run the decoder
        if self._decoder is not None:
            llr = self._decoder(llr)


        if self._return_infobits:
            return b, llr
        else:
            return c, llr
        
class E2EModel_row(tf.keras.Model):
    """End-to-end model for (GNN-)decoder evaluation.

    Parameters
    ----------
    encoder: Layer or None
        Encoder layer, no encoding applied if None.

    decoder: Layer or None
        Decoder layer, no decoding applied if None.

    k: int
        Number of information bits per codeword.

    n: int
        Codeword lengths.

    return_infobits: Boolean
        Defaults to False. If True, only the ``k`` information bits are
        returned. Must be supported be the decoder as well.

    es_no: Boolean
        Defaults to False. If True, the SNR is not rate-adjusted (i.e., Es/N0).

    Input
    -----
        batch_size: int or tf.int
            The batch_size used for the simulation.

        ebno_db: float or tf.float
            A float defining the simulation SNR.

    Output
    ------
        (c, llr):
            Tuple:

        c: tf.float32
            A tensor of shape `[batch_size, n] of 0s and 1s containing the
            transmitted codeword bits.

        llr: tf.float32
            A tensor of shape `[batch_size, n] of llrs containing estimated on
            the codeword bits.
    """

    def __init__(self, decoder, k1_new, k2_new, n1_new, n2_new, return_infobits=False, es_no=False):
        super().__init__()

        self._n1 = n1_new
        self._k1 = k1_new
        self._n2 = n2_new
        self._k2 = k2_new

 

        self._binary_source = BinarySource()
        self._num_bits_per_symbol = 2
        self._mapper = Mapper("qam", self._num_bits_per_symbol)
        self._demapper = Demapper("app", "qam", self._num_bits_per_symbol)
        self._channel = AWGN()
        self._decoder = decoder
       
        self._return_infobits = return_infobits
        self._es_no = es_no
        self._coderate = self._k1 * self._k2 / (self._k2 * self._n1 + (self._n2 - self._k2) * self._k1)

    # @tf.function(jit_compile=True)
    def call(self, batch_size, llr_channel,llr_last_rows, llr_col=None, b=None, result_col=None):

     

      
        b = b

        # and run the decoder
        if self._decoder is not None:
            if llr_col is not None and result_col is not None:

               # print('no no no no ????')
               
                llr_col= tf.reshape(llr_col, [batch_size, self._n2, self._k1])
                llr_col_slice = llr_col[:, :self._k2, :self._k1]

                result_col = tf.reshape(result_col, [batch_size, self._n2, self._k1])
                result_col_slice = result_col[:, :self._k2, :self._k1]

                llr_channel_3d=tf.reshape(llr_channel, [batch_size, self._k2, self._n1])
                llr_channel_b=llr_channel_3d[:, :self._k2, :self._k1]

                # 现在 llr_row 和 llr 的形状一致，可以进行相减操作

                result_llr = llr_col_slice - result_col_slice
                result_llr=result_llr+llr_channel_b
                result = tf.concat([result_llr, llr_last_rows], axis=2)
                
               # print('result0000:', result)
                result = tf.reshape(result, [batch_size, self._k2 * self._n1])
                #print('result row:', result)
      

                result_row_reshape= tf.reshape(result, [batch_size, self._k2, self._n1])
                
                # 准备一个列表来存储每行的结果
                decoded_rows = []

                # 对每一行应用解码器
                for i in range(self._k2):
                    row = result_row_reshape[:, i, :]  # 提取一行，形状为 (1, 12)
                    decoded_row = self._decoder(row)  # 应用解码器
                    decoded_rows.append(decoded_row)

                # 将所有解码后的行拼接在一起
                final_result = tf.concat(decoded_rows, axis=1)

                llr_hat=final_result


            else:
                #print('yes yes yes yes ????')
                result = llr_channel
                # print('result row1 :', result)
                
                result_row_reshape= tf.reshape(result, [batch_size, self._k2, self._n1])


                # 准备一个列表来存储每行的结果
                decoded_rows = []

                # 对每一行应用解码器
                for i in range(self._k2):
                    row = result_row_reshape[:, i, :]  # 提取一行，形状为 (1, 12)
                    decoded_row = self._decoder(row)  # 应用解码器
                    decoded_rows.append(decoded_row)
                
                #print('decoded_rows:', decoded_rows)
                # 将所有解码后的行拼接在一起
                final_result = tf.concat(decoded_rows, axis=1)
               # print('final result:', final_result)
               

                llr_hat=final_result
              

        if self._return_infobits:
            return b, llr_hat
        else:
            return  llr_hat, result


class E2EModel_col(tf.keras.Model):
    """End-to-end model for (GNN-)decoder evaluation.

    Parameters
    ----------
    encoder: Layer or None
        Encoder layer, no encoding applied if None.

    decoder: Layer or None
        Decoder layer, no decoding applied if None.

    k: int
        Number of information bits per codeword.

    n: int
        Codeword lengths.

    return_infobits: Boolean
        Defaults to False. If True, only the ``k`` information bits are
        returned. Must be supported be the decoder as well.

    es_no: Boolean
        Defaults to False. If True, the SNR is not rate-adjusted (i.e., Es/N0).

    Input
    -----
        batch_size: int or tf.int
            The batch_size used for the simulation.

        ebno_db: float or tf.float
            A float defining the simulation SNR.

    Output
    ------
        (c, llr):
            Tuple:

        c: tf.float32
            A tensor of shape `[batch_size, n] of 0s and 1s containing the
            transmitted codeword bits.

        llr: tf.float32
            A tensor of shape `[batch_size, n] of llrs containing estimated on
            the codeword bits.
    """

    def __init__(self,  decoder, k1, k2, n1, n2, return_infobits=False, es_no=False):
        super().__init__()

        self._n1 = n1
        self._k1 = k1
        self._n2 = n2
        self._k2 = k2

        self._binary_source = BinarySource()
        self._num_bits_per_symbol = 2
        self._mapper = Mapper("qam", self._num_bits_per_symbol)
        self._demapper = Demapper("app", "qam", self._num_bits_per_symbol)
        self._channel = AWGN()
        self._decoder = decoder
        # self._encoder = encoder
        self._return_infobits = return_infobits
        self._es_no = es_no
        self._coderate = self._k1 * self._k2 / (self._k2 * self._n1 + (self._n2 - self._k2) * self._k1)

    # @tf.function(jit_compile=True)
    def call(self, batch_size,llr_channel, llr_last_col, llr_row=None, b=None, result_row=None):

       
   
        b = b

    

        if self._decoder is not None:
            if llr_row is not None and result_row is not None:
                #print('llr_row111111111111:', llr_row)
           
                llr_row= tf.reshape(llr_row, [batch_size, self._k2, self._n1])
                llr_row_slice = llr_row[:, :self._k2, :self._k1]
                # llr_row11=tf.reshape(llr_row_slice, [batch_size, self._k2 * self._k1])

                result_row = tf.reshape(result_row, [batch_size, self._k2, self._n1])
                result_row_slice = result_row[:, :self._k2, :self._k1]
                # result_row_slice11=tf.reshape(result_row_slice, [batch_size, self._k2 * self._k1])

                
                result_llr = llr_row_slice - result_row_slice
                llr_channel_3d=tf.reshape(llr_channel, [batch_size, self._n2, self._k1])
                llr_channel_b=llr_channel_3d[:, :self._k2, :self._k1]
                result_llr=result_llr+ llr_channel_b
                result = tf.concat([ llr_channel_b, llr_last_col], axis=1)
               # result = tf.reshape(result, [batch_size, self._n2 * self._k1])
                # print('result col:', result)
                

                result_col_transpose = tf.transpose(result, perm=[0, 2, 1])
      
                # 准备一个列表来存储每行的结果
                decoded_cols = []

                # 对每一行应用解码器
                for i in range(self._k1):
                    col = result_col_transpose[:, i, :]  # 提取一列，形状为 (1, 12)
                    decoded_col = self._decoder(col)  # 应用解码器
                    decoded_cols.append(decoded_col)

                # 将所有解码后的行拼接在一起
                final_result = tf.concat(decoded_cols, axis=1)

                llr_hat_c=final_result
               # llr_hat = self._decoder(result)  ##当前的decoder并不能适用方针的解码，目前的仅仅是（batchsize, n）, 但需要使它适用（batchsize, k2, n1）
        
              
                llr_hat_c= tf.reshape(llr_hat_c, [batch_size, self._k1, self._n2])
      
                llr_hat_transpose = tf.transpose(llr_hat_c, perm=[0, 2, 1])
               
                llr_hat= tf.reshape( llr_hat_transpose, [batch_size, self._n2*self._k1])




                
            else:
                result = llr
                llr_hat = self._decoder(result)

        if self._return_infobits:
            return b, llr_hat
        else:
            return llr_hat, result

