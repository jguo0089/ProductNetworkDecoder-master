import tensorflow as tf
import numpy as np
from sionna.fec.ldpc import LDPCBPDecoder
from sionna.mapping import Mapper, Demapper
from sionna.channel import AWGN
from sionna.utils import BinarySource, snrdb2no
from sionna.utils.metrics import compute_ber
from BP_snr_two_model_update import * # load GNN functions
#from wbp import * # load weighted BP functions
from bina_encoding import row_LinearEncoder
from bina_encoding import col_LinearEncoder




tf.keras.backend.set_floatx('float32')
# 1. 使用tf.function装饰器来编译关键函数
@tf.function(jit_compile=True)
def run_simulation(b, c_combined, x_combined, sigma2, BP_model_row, BP_model_col):
    # Pass through channel
    # y_combined = channel([x_combined, no])
    # llr_channel_combined = demapper([y_combined, no])

    x_whole = (-1) **  c_combined
     

    

    # 计算噪声
    sigma = tf.sqrt(sigma2)

    # 生成高斯噪声
    noise = sigma * tf.random.normal(tf.shape( x_whole), mean=0.0, stddev=1.0)


    
    y_whole = x_whole + noise

    # 计算LLR 
    llr_channel_combined = -2 * y_whole / sigma2

    
    # Define part sizes
    part1_size = k2 * k1
    part2_size = k2 * (n1 - k1)
    part3_size = (n2 - k2) * k1
    
    # Split llr_channel_combined into three parts
    b_channel = llr_channel_combined[:, :part1_size]
    c_row_last_channel = llr_channel_combined[:, part1_size:part1_size+part2_size]
    c_col_last_channel = llr_channel_combined[:, part1_size+part2_size:]
    
    # Reshape each part to required dimensions
    b_channel_sq = tf.reshape(b_channel, [1, k2, k1])
    llr_last_row = tf.reshape(c_row_last_channel, [1, k2, n1-k1])
    llr_last_col = tf.reshape(c_col_last_channel, [1, n2-k2, k1])
    
    # Construct full LLR matrices for row and column decoders (keep as 3D)
    llr_channel_row_3d = tf.concat([b_channel_sq, llr_last_row], axis=2)  # Shape: [1, k2, n1]
    llr_channel_col_3d = tf.concat([b_channel_sq, llr_last_col], axis=1)  # Shape: [1, n2, k1]
    
    # Initialize iteration variables
    llr_col = None
    result_col = None
    
    # Iterative decoding
    for _ in range(num_iterations):
        # Row decoder forward pass (passing 3D llr_channel)
        llr_row, result_row = BP_model_row(1, llr_channel_row_3d, llr_last_row, 
                                           llr_col, b, result_col)
        
        # Column decoder forward pass (passing 3D llr_channel)
        llr_col, result_col = BP_model_col(1, llr_channel_col_3d, llr_last_col, 
                                           llr_row, b, result_row)
    
    # Final decision and BER computation
    llr_col_reshaped = tf.reshape(llr_col, [1, n2, k1])
    c_hat = tf.cast(tf.greater(llr_col_reshaped, 0), tf.float32)
    c_hat_sliced = c_hat[:, :k2, :k1]
    
    return tf.cast(compute_ber(b, c_hat_sliced), tf.float32)

# 2. 预先计算一些常量
# k1, k2, n1, n2 = 2, 32, 3,48
# k1_new, k2_new, n1_new, n2_new = k1, k2, n1, n2
num_iterations =3
ITER = 10000
SNR_vec = tf.range(0, 9.0, 1.0, dtype=tf.float32)
SNR_len = len(SNR_vec)

# 3. 使用tf.TensorArray来存储结果
ber_record = tf.TensorArray(tf.float32, size=ITER * SNR_len, dynamic_size=False, clear_after_read=False)

# 4. 初始化模型和其他组件
binary_source = BinarySource()
mapper = Mapper("qam", 2)
demapper = Demapper("app", "qam", 2)
channel = AWGN()

# pcm =  np.load('LDPC/ldpc_H_3_2_911.npy')
# G_sys_np = np.load('LDPC/ldpc_G_3_2_911.npy')
# pcm=pcm.reshape(1,-1)##转换成1行n列


# pcm_col =  np.load('LDPC/ldpc_H_48_32_911.npy')
# G_sys_np_col = np.load('LDPC/ldpc_G_48_32_911.npy')

pcm = np.loadtxt('PR/H_pr_k2n3.txt')
G_sys_np = np.loadtxt('PR/G_pr_k2n3.txt')
pcm=pcm.reshape(1,-1)##转换成1行n列


pcm_col = np.loadtxt('PR/H_pr_k8n16.txt')
G_sys_np_col = np.loadtxt('PR/G_pr_k8n16.txt')


k1 = G_sys_np.shape[0]  # 生成矩阵的行数 = 信息位长度
n1 = G_sys_np.shape[1]  # 生成矩阵的列数 = 码字长度
k2 =G_sys_np_col.shape[0]  # 列码的信息位长度
n2 = G_sys_np_col.shape[1]  # 列码的码字长度
print('k1:',k1)
print('n1:',n1)
print('k2:',k2)
print('n2:',n2)
k1_new, k2_new, n1_new, n2_new = k1, k2, n1, n2
# pcm = np.load('ldpc/ldpc_H_12_8smallnew813.npy')
# G_sys_np = np.load('ldpc/ldpc_G_12_8smallenew813.npy')

# pcm_col=np.load('ldpc/ldpc_H_12_8smallnew813.npy')
# G_sys_np_col =np.load('ldpc/ldpc_G_12_8smallenew813.npy')

# pcm_col=np.load('ldpc/ldpc_H_24_8smallnew820.npy')
# G_sys_np_col =np.load('ldpc/ldpc_G_24_8smallenew820.npy')

encoder_row = row_LinearEncoder(G_sys_np, is_pcm=False)
encoder_col = col_LinearEncoder(G_sys_np_col, is_pcm=False)

bp_decoder_row = LDPCBPDecoder(pcm, num_iter=20, hard_out=False)
bp_decoder_col = LDPCBPDecoder(pcm_col, num_iter=20, hard_out=False)

BP_model_row = E2EModel_row(bp_decoder_row, k1_new, k2_new, n1_new, n2_new)
BP_model_col = E2EModel_col(bp_decoder_col, k1_new, k2_new, n1_new, n2_new)

# 5. 主循环
for tot_idx in range(ITER):
    b = binary_source([1, k2, k1])

    row_codewords = encoder_row(b)
    c_row = tf.reshape(row_codewords, [1, k2 * n1])
    x_row = mapper(c_row)
    
    col_codewords = encoder_col(b)
    c_col = tf.reshape(col_codewords, [1, n2 * k1])
    x_col = mapper(c_col)


    b = binary_source([1, k2, k1])
    b_reshape = tf.reshape(b, [1, k2 * k1])

    # Row encoding
    row_codewords = encoder_row(b)
    c_row_last = row_codewords[:, :, -(n1-k1):]  # Extract parity bits only
    llr_last_row_reshape = tf.reshape(c_row_last, [1, k2 * (n1-k1)])

    # Column encoding  
    col_codewords = encoder_col(b)
    c_col_last = col_codewords[:, -(n2 - k2):, :]  # Extract parity bits only
    llr_last_col_reshape = tf.reshape(c_col_last, [1, (n2-k2) * k1])

    # Concatenate three parts: info bits, row parity, column parity
    c_combined = tf.concat([b_reshape, llr_last_row_reshape, llr_last_col_reshape], axis=1)

    # Channel processing for combined codeword
    x_combined = mapper(c_combined)

    



    print('c_combined shape:', c_combined.shape)

    for SNR_idx, snr in enumerate(SNR_vec):

        snr_linear = tf.pow(10.0,  snr / 10.0)

        # 计算噪声方差
        sigma2 = 1.0 / snr_linear
    
       



        no = snrdb2no(snr)
        ber = run_simulation(b, c_combined, x_combined, sigma2, BP_model_row, BP_model_col)
        ber_record = ber_record.write(tot_idx * SNR_len + SNR_idx, ber)

# 6. 计算最终结果
ber_results = tf.reshape(ber_record.stack(), [ITER, SNR_len])
ber_avg_record = tf.reduce_mean(ber_results, axis=0)
BLER_array = tf.reduce_mean(tf.cast(ber_results > 0, tf.float32), axis=0)

print("BLER List:", BLER_array.numpy().tolist())
print("BER List:", ber_avg_record.numpy().tolist())
#input("按回车键继续...")  # 添加这一行